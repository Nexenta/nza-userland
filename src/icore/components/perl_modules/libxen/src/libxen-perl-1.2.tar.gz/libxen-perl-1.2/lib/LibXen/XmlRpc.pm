#
# Copyright (C) 2006-2009 Nexenta Systems, Inc.
# All rights reserved.
#

use strict;
use NZA::Common;

sub LibXen::XmlRpc::enable_debug {
	my ($lvl) = @_;
	$lvl = $NZA::TRACE_LEVEL_DEFAULT unless $lvl;
	$LibXen::XmlRpc::Client::trace_level = $lvl;
}

sub LibXen::XmlRpc::disable_debug {
	$LibXen::XmlRpc::Client::trace_level = $NZA::TRACE_LEVEL_VVV;
}

#############################################################################
package LibXen::XmlRpc::Param;
#############################################################################

use strict;
use warnings;

our $type_re = qr/^(i4|int|boolean|string|double|dateTime.iso8601|base64)$/;

###
sub new {
	my ($class, $val, $type) = @_;

	$type = 'string' unless defined $type;

	my $self = { val => $val };
	bless $self, $class;

	$self->type($type);

	return $self;
};

###
sub value {
	my ($self, $new_val) = @_;

	my $val =  $self->{val};

	$self->{val} = $new_val if defined $new_val;

	return $val;
};

###
sub type {
	my ($self, $new_type) = @_;

	Carp::croak("Invalid parameter type: $new_type\n")
		if defined $new_type && $new_type !~ /$type_re/;

	my $type = $self->{type};

	$self->{type} = $new_type if defined $new_type;

	return $type;
};


#############################################################################
package LibXen::XmlRpc::Fault;
#############################################################################

###
sub new {
	my ($class, $fault_code, $fault_str) = @_;

	my $self = {
		faultCode => $fault_code,
		faultString => $fault_str,
	};
	bless $self, $class;

	return $self;
};

###
sub fault_code {
	my ($self) = @_;

	return $self->{faultCode};
};

###
sub fault_string {
	my ($self) = @_;

	return $self->{faultString};
};


#############################################################################
package LibXen::XmlRpc::Response;
#############################################################################

use strict;
use warnings;

###
sub new {
	my ($class, $params) = @_;

	my $self = {
		params => $params
	};
	bless $self, $class;

	return $self;
};

###
sub params {
	my ($self) = @_;

	return $self->{params};
};


#############################################################################
package LibXen::XmlRpc::Client;
#############################################################################

use strict;
use warnings;

use Carp qw(confess croak);
use XML::LibXML;
use LWP::UserAgent;
use HTTP::Request;
use HTTP::Headers;
use HTTP::Response;
use HTTP::Cookies;
#use Data::Dumper;

use NZA::Common;

our $trace_level = $NZA::TRACE_LEVEL_VVV;

###
sub new {
	my ($class, $url, $timeout) = @_;

	my $user_agent = LWP::UserAgent->new;
	$user_agent->timeout($timeout) if $timeout;
# 
# 	my $cookie_jar = HTTP::Cookies->new(ignore_discard => 1);
# 	$user_agent->cookie_jar( $cookie_jar );
# 
	$user_agent->protocols_allowed( ['http', 'https'] );
	my $self = {
		user_agent => $user_agent,
		url => $url
	};
	bless $self, $class;
	
	return $self;
};

###
sub url {
	my ($self, $new_url) = @_;

	my $url =  $self->{url};

	$self->{url} = $new_url if defined $new_url;

	return $url;
}

###
sub timeout {
	my ($self, $new_val) = @_;

	my $val =  $self->{user_agent}->timeout;

	$self->{user_agent}->timeout($new_val) if defined $new_val;

	return $val;
}

###
sub byte_length {
    my ($string) = @_;

    use bytes;
    return length($string);
}

###
sub _make_params {
	my ($self, $doc, $root, @param_list) = @_;

	my $params = $doc->createElement('params');
	$root->addChild($params);

	foreach my $p (@param_list) {
		$self->_make_param($doc, $params, $p);
	}

}

###
sub _make_param {
	my ($self, $doc, $params, $p) = @_;

	my $param = $doc->createElement('param');

	$params->addChild($param);

	if (defined($p)) {
		$self->_make_value($doc, $param, $p);
	} else {
		$self->_make_nil($doc, $param);
	}

}

###
sub _make_value {
	my ($self, $doc, $val_container, $val) = @_;

	my $value = $doc->createElement('value');
	$val_container->addChild($value);

	if (defined($val)) {
		if (ref($val) eq 'ARRAY') {
			$self->_make_array($doc, $value, $val);
		} elsif (ref($val) eq 'HASH') {
			$self->_make_struct($doc, $value, $val);
		} else {
			$self->_make_type($doc, $value, $val);
		}
	} else {
		$self->_make_nil($doc, $value);
	}

}

###
sub _make_nil {
	my ($self, $doc, $value) = @_;

	my $nil = $doc->createElement('nil');
	$value->addChild($nil);
}

###
sub _make_type {
	my ($self, $doc, $value, $p) = @_;

	return unless defined $p;

	my $typ = 'string';
	my $val = '';
	if (ref($p) eq 'LibXen::XmlRpc::Param') {
		$typ = $p->type;
		$val = $p->value;
	} else {
		$val = $p;
	}

	my $type = $doc->createElement($typ);
	$type->appendText($val);
	$value->addChild($type);
}

###
sub _make_array {
	my ($self, $doc, $value, $parr) = @_;

	return unless defined $parr && ref($parr) eq 'ARRAY';

	my $array = $doc->createElement('array');
	my $data = $doc->createElement('data');

	$array->addChild($data);
	$value->addChild($array);

	foreach my $p (@$parr) {
		$self->_make_value($doc, $data, $p);
	}
}

###
sub _make_struct {
	my ($self, $doc, $value, $phash) = @_;

	return unless defined $phash && ref($phash) eq 'HASH';

	my $struct = $doc->createElement('struct');
	$value->addChild($struct);

	foreach my $k (keys %$phash) {
		my $p = $phash->{$k};
		$self->_make_struct_member($doc, $struct, $k, $p);
	}
}

###
sub _make_struct_member {
	my ($self, $doc, $struct, $k, $memberval) = @_;

	my $member = $doc->createElement('member');
	my $name = $doc->createElement('name');

	$name->appendText($k);

	$member->addChild($name);
	$struct->addChild($member);

	$self->_make_value($doc, $member, $memberval);
}

sub _make_body {
	my ($self, $method_name, @params) = @_;

	my $doc = XML::LibXML::Document->new;
	my $root = $doc->createElement('methodCall');
	$doc->setDocumentElement($root);

	my $methodName = $doc->createElement('methodName');
	$root->addChild($methodName);
	$methodName->appendText($method_name);

	$self->_make_params($doc, $root, @params);

	return $doc->toString(1);
}

sub request {
   my ($self, $url, $body_content) = @_;
   my $user_agent = $self->{user_agent};

   # http header
   my $http_header = HTTP::Headers->new(
                        Content_Type => 'text/xml',
                        Content_Length => byte_length($body_content));
   # request
   my $request = HTTP::Request->new('POST',
                                    $url,
                                    $http_header,
                                    $body_content);
   
   # send request
   TRACE($trace_level, "Request:\n".$request->content);
   my $response = $user_agent->request($request);
   my $result;   
   eval {
	   $result = $response->content;
   }; if ($@) {
      # response is not well formed xml - possibly be a setup issue
      die "XML-RPC request error - possibly a protocol issue: ".$response->content;
   }   

   return $result;
}

sub call {
	my ($self, $method, $params) = @_;

	my $request = $self->_make_body($method, @$params);

	TRACE($NZA::TRACE_LEVEL_V, "XML-RPC CALL: $method");
	my $response = $self->request($self->url, $request);

	my $xml_parser = XML::LibXML->new;   
   	my $resp = $xml_parser->parse_string($response);
	TRACE($trace_level, "Response:\n".$resp->toString(1));
	my $method_resp = $resp->getDocumentElement();
	my ($fault) = $method_resp->getChildrenByTagName('fault');
	if ($fault) { # FAULT
		my ($value) = $fault->getChildrenByTagName('value');
		my $fault_struc = $self->_parse_value($value);
		my $fault = LibXen::XmlRpc::Fault->new($fault_struc->{faultCode}, $fault_struc->{faultString});

		return (1, $fault);
	} else {
		my ($params) = $method_resp->getChildrenByTagName('params');
		my $result = $self->_parse_params($params);
		my $response = LibXen::XmlRpc::Response->new($result);

		return (0, $response);
	}

}

###
sub _parse_params {
	my ($self, $params) = @_;

	my @result = ();
	my @params = $params->getChildrenByTagName('param');
	foreach my $param (@params) {
		my ($value) = $param->getChildrenByTagName('value');

		my $val = $self->_parse_value($value);
		push @result, $val;
	}

	return \@result;
}

###
sub _parse_value {
	my ($self, $value) = @_;

	my ($type) = $value->firstChild();
	return undef unless defined $type; # nil

	my $typename = $type->localname;

	if (defined($typename)) {
		if ($typename eq 'array') {
			return $self->_parse_array($type);
		} elsif ($typename eq 'struct') {
			return $self->_parse_struct($type);
		} elsif ($typename eq 'nil') {
			#return undef;
			return '';
		} else {
			my $valstr = $type->textContent;
			chomp($valstr);
			return $valstr;
# 
# 			my $val = LibXen::XmlRpc::Param->new($valstr, $typename);
# 			return $val;
# 
		} 
	} else {
		my $valstr = $value->textContent;
		chomp($valstr);
		return $valstr;
	}
}

###
sub _parse_array {
	my ($self, $array) = @_;

	my @result = ();

	my ($data) = $array->getChildrenByTagName('data');
	my @values = $data->getChildrenByTagName('value');

	foreach my $value (@values) {
		my $val = $self->_parse_value($value);
		push @result, $val;
	}

	return \@result;
}

###
sub _parse_struct {
	my ($self, $struct) = @_;

	my %result = ();

	my @members = $struct->getChildrenByTagName('member');

	foreach my $member (@members) {
		my ($name) = $member->getChildrenByTagName('name');
		my ($value) = $member->getChildrenByTagName('value');

		my $key = $name->textContent;
		chomp($key);
		my $val = $self->_parse_value($value);

		$result{$key} = $val;
	}

	return \%result;
}

1;
__END__
