#
# Copyright (C) 2006-2009 Nexenta Systems, Inc.
# All rights reserved.
#

use LibXen::XmlRpc;

### Errors:
# SESSION_AUTHENTICATION_FAILED
# FIELD_TYPE_ERROR
# MESSAGE_METHOD_UNKNOWN


#############################################################################
package LibXen::Xen::Session;
#############################################################################

use strict;
use warnings;

use NZA::Common;
use NZA::Exception;

###
sub new {
	my ($class, $xmlrpc_client) = @_;

	ASSERT($xmlrpc_client && $xmlrpc_client->isa('LibXen::XmlRpc::Client'), 'xmlrpc client defined');

	my $self = {
		id => undef,
		xmlrpc_client => $xmlrpc_client
	};
	bless $self, $class;

	return $self;
};

###
sub id {
	my ($self) = @_;

	return $self->{id};
}

###
sub _call {
	my ($self, $method, $method_params) = @_;

	ASSERT(defined($method), "xen server method defined");
	ASSERT(defined($method_params) && ref($method_params) eq 'ARRAY', "xen server method parameters defined");

	my ($err, $response) = $self->{xmlrpc_client}->call($method, $method_params);
	if ($err) {
		my $fault = $response;
		die "Xen XML-RPC request fault: errcode: ".$fault->fault_code." errstr: ".$fault->fault_string."\n";
	}

	my $resp = $response->params->[0]; # only 1 param - struct should be returned
	my $status = $resp->{Status};

	TRACE($NZA::TRACE_LEVEL_VV, "Xen response status: $status");

	if ($status eq 'Failure') {
		my $errdesc = $resp->{ErrorDescription};
		#my @errlines = grep { !/^\s*$/ } @$errdesc;
		my @errlines = map { defined($_) ? $_ : '' } @$errdesc;
		die join("\n", @errlines);
	}

	if ($status ne 'Success') {
		die "Xen XML-RPC request fault: invalid response\n";
	}

	return $resp->{Value};
}

###
sub call {
	my ($self, $method, $method_params) = @_;

	ASSERT(defined($method), "xen server method defined");
	ASSERT(defined($method_params) && ref($method_params) eq 'ARRAY', "xen server method parameters defined");

	return unless $self->id;

	unshift @$method_params, $self->id;

	return $self->_call($method, $method_params);
}

###
sub login {
	my ($self, $username, $password) = @_;

	if ($self->{id}) {
		TRACE("Warning!: trying to loing while prev Xen session exists: $self->{id}");
		$self->{id} = undef;
	}

	$self->{id} = $self->_call('session.login_with_password', [ $username, $password ]);
}

###
sub logout {
	my ($self) = @_;

	return unless $self->{id};

	$self->{id} = $self->_call('session.logout', [ $self->{id} ]);
}


#############################################################################
package LibXen::Xen::Server;
#############################################################################

use strict;
use warnings;

###
sub new {
	my ($class, $url, $timeout) = @_;

	my $client = LibXen::XmlRpc::Client->new($url, $timeout);
	my $session = LibXen::Xen::Session->new($client);

	my $self = {
		client => $client,
		session => $session
	};
	bless $self, $class;

	return $self;
};

###
sub timeout {
	my ($self, $new_val) = @_;

	my $val =  $self->{client}->timeout;

	$self->{client}->timeout($new_val) if defined $new_val;

	return $val;
}

###
sub session_id {
	my ($self) = @_;

	return $self->{session}->id;
}

###
sub login {
	my ($self, $username, $password) = @_;

	$self->{session}->login($username, $password);
}

###
sub logout {
	my ($self) = @_;

	$self->{session}->logout();
}

###
sub call {
	my $self = shift @_;
	my $method = shift @_;
	my $params = $_[0];

	if (!defined($params)) {
		$params = [];
	} elsif (ref($params) ne 'ARRAY') {
		$params = \@_;
	}

	return $self->{session}->call($method, $params);
}


#############################################################################
package LibXen::Xen::SR;
#############################################################################

use strict;
use warnings;

###
sub new {
	my ($class, $xenserver, $name) = @_;

	my $self = {
		xenserver => $xenserver,
	};
	bless $self, $class;

	return $self;
};

1;
__END__
