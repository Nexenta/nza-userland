#!/bin/sh
set -e
# for the lazy typer
ruby -w -I ../../lib gdbus
