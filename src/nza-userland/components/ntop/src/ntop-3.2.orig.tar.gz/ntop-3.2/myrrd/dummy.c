#include "rrd_tool.h"

void gdImageGif(gdImagePtr  gif, FILE  *fo);

void gdImageGif(gdImagePtr  gif, FILE  *fo) {;}

/* Wots dis?
 *   gdImageGif was pulled from gd and not restored until v2.0.28 (21Jul2004)
 *   after Unisys' patent ran out world-wide.  So the code in rrdtool v1.0.49 that references
 *   gdImageGif has nothing to hook into on many systems.
 *
 * This fake routine keeps the linker happy
 *
 */
