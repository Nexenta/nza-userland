
#ifndef _GDLUCIDAB12L2_H_
#define _GDLUCIDAB12L2_H_ 1

/*
	This is a header file for gd font, generated using
	bdftogd version 0.60 by Jan Pazdziora, adelton@fi.muni.cz
	from bdf font
	-B&H-LucidaTypewriter-Medium-R-Normal-Sans-12-120-75-75-M-70-iso8859-2
	at Wed Apr  2 23:46:21 2003.
	The original bdf was holding following copyright:
	"Copyright Bigelow & Holmes 1986, 1985."
 */


#include "gd.h"

extern gdFontPtr gdLucidaBold12l2;

#endif

