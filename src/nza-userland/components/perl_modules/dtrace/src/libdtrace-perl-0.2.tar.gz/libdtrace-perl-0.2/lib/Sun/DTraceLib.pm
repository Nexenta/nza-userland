package Sun::DTraceLib;
use strict;
use warnings;

BEGIN {
	our $VERSION = '1.0';
	require XSLoader;
	XSLoader::load('Sun::DTraceLib', $VERSION);
}

1;

__END__

=head1 NAME

Sun::DTraceLib - a DTrace consumer API in Perl

=head1 SYNOPSIS

  use Sun::DTraceLib;

=head1 DESCRIPTION


=head1 METHODS

=head2 compile

=head2 execute

=cut
