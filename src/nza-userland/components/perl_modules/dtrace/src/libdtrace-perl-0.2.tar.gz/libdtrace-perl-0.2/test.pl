#!/usr/bin/perl -w

BEGIN {
	unshift @INC, "./lib";
	unshift @INC, "./blib/arch/auto/Sun/DTraceLib/";
}

use Data::Dumper;
use Sun::DTraceLib;

sub callback {
	my $line = shift;
	print $line;
}

my $dlib = new Sun::DTraceLib(\&callback);

my $prog1 = $dlib->program_fcompile("./spasync.d");
#open FD1, "./a.d"; my @s1 = <FD1>; close FD1;
#my $prog1 = $dlib->program_strcompile("@s1");

my $prog2 = $dlib->program_fcompile("./a.d");
#open FD2, "./spasync.d"; my @s2 = <FD2>; close FD2;
#my $prog2 = $dlib->program_strcompile("@s2");

#my $prog7 = $dlib->program_strcompile("@s1");
#
#my $prog1 = $dlib->program_strcompile('sdt:::interrupt-start { @num1[cpu] = count(); }');
#my $prog2 = $dlib->program_strcompile('sdt:::interrupt-start { @num2[cpu] = count(); }');
#my $prog3 = $dlib->program_strcompile('sdt:::interrupt-start { @num3[cpu] = count(); }');
#my $prog4 = $dlib->program_strcompile('sdt:::interrupt-start { @num4[cpu] = count(); }');
#my $prog5 = $dlib->program_strcompile('sdt:::interrupt-start { @num5[cpu] = count(); }');
$dlib->program_exec($prog1);
$dlib->program_exec($prog2);
#$dlib->program_exec($prog6);
#$dlib->program_exec($prog7);

#my $prog2 = $dlib->program_strcompile('dtrace:::BEGIN { printf("Hello, world!\n"); exit(0); }');
#$dlib->program_exec($prog2);
#$dlib->program_exec($prog3);
#$dlib->program_exec($prog4);
#$dlib->program_exec($prog5);
$dlib->go();

#&Data::Dumper::Dumpp([$prog]);

while ($dlib->work()) {
#	$dlib->sleep();
	sleep 1;
	$dlib->aggregate_snap();
	$dlib->aggregate_print();
	$dlib->aggregate_clear();
};

exit(0);
