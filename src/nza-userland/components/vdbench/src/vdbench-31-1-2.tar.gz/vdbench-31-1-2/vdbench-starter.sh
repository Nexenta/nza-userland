#!/bin/bash

/opt/vdbench/vdbench.bash $@
