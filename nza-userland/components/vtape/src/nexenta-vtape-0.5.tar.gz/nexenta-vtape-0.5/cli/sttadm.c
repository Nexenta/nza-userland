/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License (the "License").
 * You may not use this file except in compliance with the License.
 *
 * You can obtain a copy of the license at usr/src/OPENSOLARIS.LICENSE
 * or http://www.opensolaris.org/os/licensing.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at usr/src/OPENSOLARIS.LICENSE.
 * If applicable, add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your own identifying
 * information: Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 */

/*
 * Copyright 2010 Nexenta Systems.  All rights reserved.
 * Use is subject to license terms.
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/varargs.h>
#include <libstmf.h>

#include <sys/stmf.h>
#include <sys/stmf_ioctl.h>
#include "stt_ioctl.h"

#define	STTDEV	"/devices/pseudo/stt@0:admin"
int sttfd;
stmf_iocdata_t iocd;
char g_str[64];
char *stt_err_strs[] = STT_ERR_STRS;

#define	H(str)	fprintf(stderr, str);

void
print_err(char *str, char *str2, int err)
{
	fprintf(stderr, "%s %s %s\n%s\n", str, str2 ? ":" : "",
	    str2 ? str2 : "",
	    ((err > 0) && (err < STT_MAX_ERR)) ? stt_err_strs[err] : "");
}

int
aton(char a)
{
	if (((a) >= 'a') && ((a) <= 'f')) {
		return (a - 'a' + 10);
	} else if (((a) >= 'A') && ((a) <= 'F')) {
		return (a - 'A' + 10);
	} else if (((a) >= '0') && ((a) <= '9')) {
		return (a - '0');
	}
	return (-1);
}

void
mkf(char *n)
{
	int fd;

	fd = open(n, O_CREAT | O_RDWR, 0644);
	if (fd >= 0)
		close(fd);
}

void
guid_to_str(uint8_t *guid, char *str)
{
	int i;

	for (i = 0; i < 16; i++) {
		sprintf(str, "%02x", guid[i]);
		str += 2;
	}
}

char *
guid2str(uint8_t *guid)
{
	guid_to_str(guid, g_str);
	return (g_str);
}

int
str_to_guid(char *str, uint8_t *guid)
{
	int i;
	int c, d;

	if (strlen(str) != 32)
		return (0);
	for (i = 0; i < 16; i++) {
		c = aton(str[0]);
		d = aton(str[1]);
		if ((c < 0) || (d < 0))
			return (0);
		guid[i] = ((c << 4) | d) & 0xff;
		str += 2;
	}

	return (1);
}

int
path_to_guid(char *path, uint8_t *guid)
{
	bzero(&iocd, sizeof(iocd));
	iocd.stmf_version = STMF_VERSION_1;
	iocd.stmf_obuf_size = 16;
	iocd.stmf_obuf = (uint64_t)guid;
	iocd.stmf_ibuf_size = strlen(path) + 1;
	iocd.stmf_ibuf = (uint64_t)path;
	return (ioctl(sttfd, STT_IOC_GET_DRIVE_GUID, &iocd));
}

void
usage()
{
	H("\nUsage: sttadm <cmd> [cmd-specific-params]\n\n");
	H("cmd can be one of the following:\n");
	H("  help, -?\n");
	H("\tPrints this message\n");
	H("  create-drive <meta-file>\n");
	H("\tCreates a SCSI LU emulating a Tape drive and registers this LU\n");
	H("\twith COMSTAR\n");
	H("  delete-drive <GUID>\n");
	H("\tDeregisters the Tape drive with the specified GUID\n");
	H("  list-drives [ -v ]\n");
	H("\tLists the currently registered drives by their GUIDs\n");
	H("\tSpecify -v for a more verbose listing\n");
	H("  init-media [ -s <meta-size-in-KB> ] <media-file>\n");
	H("\tFormats the media so that it can be loaded into a drive\n");
	H("\tUse -s to specify an alternate size for metadata\n");
	H("  load-media <media-file> <GUID>\n");
	H("\tLoads media-file into the drive specified by GUID\n");
	H("  unload-media [ -f ] <GUID>\n");
	H("\tUnloads the media from the drive specified by GUID\n");
	H("\tSpecify -f to force unload if the drive door is locked\n");
	H("  drive-info [ -v ] <GUID>\n");
	H("\tPrints detailed drive information\n");
	H("\tSpecify -v to include partition information as well\n");

	exit(1);
}

int
list_drives(int argc, char **argv)
{
	uint32_t n = 16;
	int verbose = 0;
	uint8_t *buf, *p;
	stt_drive_info_t *di;
	int i, sz, ret;
	nvlist_t *nvl = NULL;
	char str[33];

	if (argc > 1) {
		if ((argc != 2) || (strcmp(argv[1], "-v") != 0)) {
			H("Invalid option specified\n");
			usage();
		}
		verbose = 1;
	}
get_list_again:
	sz = n * 16;
	buf = malloc(sz);
	if (buf == NULL) {
		H("Memory allocation failure\n");
		exit(1);
	}
	bzero(&iocd, sizeof(iocd));
	iocd.stmf_version = STMF_VERSION_1;
	iocd.stmf_obuf_size = sz;
	iocd.stmf_obuf = (uint64_t)buf;
	ret = ioctl(sttfd, STT_IOC_GET_DRIVE_LIST, &iocd);
	if (ret < 0) {
		ret = errno;
		print_err("Unable to create drive", argv[1], iocd.stmf_error);
		return (ret);
	}
	if (iocd.stmf_obuf_max_nentries > n) {
		free(buf);
		n = iocd.stmf_obuf_max_nentries;
		goto get_list_again;
	}
	n = iocd.stmf_obuf_nentries;

	stmfGetProviderData("stt", &nvl, STMF_LU_PROVIDER_TYPE);
	/* For each drive, get drive info */
	di = malloc(sizeof (*di));
	if (buf == NULL) {
		H("Memory allocation failure\n");
		exit(1);
	}

	for (i = 0; i < n; i++) {
		p = &buf[i << 4];
		guid_to_str(p, str);
		if (nvl) {
			nvlist_remove(nvl, str, DATA_TYPE_STRING);
		}
		if (!verbose) {
			printf("%s\n", str);
			continue;
		}
		bzero(&iocd, sizeof(iocd));
		iocd.stmf_version = STMF_VERSION_1;
		iocd.stmf_ibuf_size = 16;
		iocd.stmf_ibuf = (uint64_t)p;
		iocd.stmf_obuf_size = sizeof (*di);
		iocd.stmf_obuf = (uint64_t)di;
		ret = ioctl(sttfd, STT_IOC_GET_DRIVE_INFO, &iocd);
		if (ret < 0) {
			ret = errno;
			print_err("Unable to get drive info for drive",
			    str, iocd.stmf_error);
			continue;
		}
		printf("Drive : %s\n", di->meta_file_name);
		printf("    GUID  : %s\n", str);
		printf("    Media : %s\n", di->media_file_name[0] ?
		    di->media_file_name : "<not present>");
	}
	if (nvl) {
		nvpair_t *kv = NULL;
		char *d;

		while ((kv = nvlist_next_nvpair(nvl, kv)) != NULL) {
			if (nvpair_value_string(kv, &d))
				continue;
			if (!verbose) {
				printf("%s\n", nvpair_name(kv));
				continue;
			}
			printf("Drive : %s\n", d);
			printf("    GUID  : %s\n", nvpair_name(kv));
			printf("    ***THIS DRIVE FAILED TO LOAD***\n");
		}
		nvlist_free(nvl);
	}
	free(di);
	free(buf);
	return (0);
}

#define	MAX_PROVIDER_RETRY 30

int
manage_persist(uint8_t *guid, char *filename, boolean_t persist)
{
	char	    guidAsciiBuf[33] = {0};
	nvlist_t    *nvl = NULL;

	uint64_t    setToken;
	boolean_t   retryGetProviderData = B_FALSE;
	boolean_t   newData = B_FALSE;
	int	    ret = STMF_STATUS_SUCCESS;
	int	    retryCnt = 0;
	int	    stmfRet;

	/* if we're persisting a guid, there must be a filename */
	if (persist && !filename) {
		return (1);
	}

	/* guid is stored in lowercase ascii hex */
	(void) snprintf(guidAsciiBuf, sizeof (guidAsciiBuf),
	    "%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x"
	    "%02x%02x%02x%02x%02x%02x",
	    guid[0], guid[1], guid[2], guid[3],
	    guid[4], guid[5], guid[6], guid[7],
	    guid[8], guid[9], guid[10], guid[11],
	    guid[12], guid[13], guid[14], guid[15]);


	do {
		retryGetProviderData = B_FALSE;
		stmfRet = stmfGetProviderDataProt("stt", &nvl,
		    STMF_LU_PROVIDER_TYPE, &setToken);
		if (stmfRet != STMF_STATUS_SUCCESS) {
			if (persist && stmfRet == STMF_ERROR_NOT_FOUND) {
				ret = nvlist_alloc(&nvl, NV_UNIQUE_NAME, 0);
				if (ret != 0) {
					ret = STMF_STATUS_ERROR;
					goto done;
				}
				newData = B_TRUE;
			} else {
				if (persist) {
					ret = stmfRet;
				}
				goto done;
			}
		}
		if (persist) {
			ret = nvlist_add_string(nvl, guidAsciiBuf, filename);
		} else {
			ret = nvlist_remove(nvl, guidAsciiBuf,
			    DATA_TYPE_STRING);
		}
		if (ret == 0) {
			if (newData) {
				stmfRet = stmfSetProviderDataProt("stt", nvl,
				    STMF_LU_PROVIDER_TYPE, NULL);
			} else {
				stmfRet = stmfSetProviderDataProt("stt", nvl,
				    STMF_LU_PROVIDER_TYPE, &setToken);
			}
			if (stmfRet != STMF_STATUS_SUCCESS) {
				if (stmfRet == STMF_ERROR_BUSY) {
					retryGetProviderData = B_TRUE;
					if (retryCnt++ > MAX_PROVIDER_RETRY) {
						ret = stmfRet;
						break;
					}
					continue;
				} else if (stmfRet ==
				    STMF_ERROR_PROV_DATA_STALE) {
					/* update failed, try again */
					nvlist_free(nvl);
					nvl = NULL;
					retryGetProviderData = B_TRUE;
					if (retryCnt++ > MAX_PROVIDER_RETRY) {
						ret = stmfRet;
						break;
					}
					continue;
				} else {
					ret = stmfRet;
				}
				break;
			}
		}
	} while (retryGetProviderData);

done:
	nvlist_free(nvl);
	return (ret);
}

int
create_drive(int argc, char **argv)
{
	int ret;
	stt_create_import_drive_t c;

	if (argc != 2) {
		H("No meta file name specified\n");
		usage();
	}
	mkf(argv[1]);
	bzero(&c, sizeof (c));
	strncpy(c.meta_file, argv[1], 255);
	c.meta_file[255] = 0;

	bzero(&iocd, sizeof(iocd));
	iocd.stmf_version = STMF_VERSION_1;
	iocd.stmf_ibuf_size = sizeof(c);
	iocd.stmf_ibuf = (uint64_t)&c;
	iocd.stmf_obuf_size = sizeof(c);
	iocd.stmf_obuf = (uint64_t)&c;
	ret = ioctl(sttfd, STT_IOC_CREATE_DRIVE, &iocd);
	if (ret < 0) {
		ret = errno;
		print_err("Unable to create drive", argv[1], iocd.stmf_error);
	} else {
		printf("Drive created. GUID is %s\n", guid2str(c.ret_guid));
		ret = manage_persist(c.ret_guid, c.meta_file, B_TRUE);
		if (ret) {
			H("Failed to update persistance database. Drive may"
			    " not show up after reboot\n");
			fprintf(stderr, "Do sttadm import-drive %s"
			    " after reboot\n", c.meta_file);
		}
	}

	return (ret);
}

int
import_drive(int argc, char **argv)
{
	int ret;
	stt_create_import_drive_t c;

	if (argc != 2) {
		H("No meta file name specified\n");
		usage();
	}
	bzero(&c, sizeof (c));
	strncpy(c.meta_file, argv[1], 255);
	c.meta_file[255] = 0;

	bzero(&iocd, sizeof(iocd));
	iocd.stmf_version = STMF_VERSION_1;
	iocd.stmf_ibuf_size = sizeof(c);
	iocd.stmf_ibuf = (uint64_t)&c;
	iocd.stmf_obuf_size = sizeof(c);
	iocd.stmf_obuf = (uint64_t)&c;
	ret = ioctl(sttfd, STT_IOC_IMPORT_DRIVE, &iocd);
	if (ret < 0) {
		ret = errno;
		print_err("Unable to import drive", argv[1], iocd.stmf_error);
	} else {
		printf("Drive imported. GUID is %s\n", guid2str(c.ret_guid));
		ret = manage_persist(c.ret_guid, c.meta_file, B_TRUE);
		if (ret) {
			H("Failed to update persistance database. Drive may"
			    " not show up after reboot\n");
			fprintf(stderr, "Do sttadm import-drive %s"
			    " after reboot\n", c.meta_file);
		}
	}

	return (ret);
}

int
delete_drive(int argc, char **argv)
{
	int ret;
	int ret2;
	stt_delete_drive_t c;

	if (argc != 2) {
		H("No drive/drive-GUID specified\n");
		usage();
	}
	bzero(&c, sizeof (c));
	if (argv[1][0] == '/') {
		if (path_to_guid(argv[1], c.drive_guid)) {
			fprintf(stderr, "Invalid drive specified %s\n",
			    argv[1]);
			exit(1);
		}
	} else if (!str_to_guid(argv[1], c.drive_guid)) {
		fprintf(stderr, "Invalid guid specified %s\n", argv[1]);
		exit(1);
	}
	bzero(&iocd, sizeof(iocd));
	iocd.stmf_version = STMF_VERSION_1;
	iocd.stmf_ibuf_size = sizeof(c);
	iocd.stmf_ibuf = (uint64_t)&c;
	ret = ioctl(sttfd, STT_IOC_DELETE_DRIVE, &iocd);
	if ((ret < 0) && (iocd.stmf_error != STT_ERR_DRIVE_NOT_FOUND)) {
		ret = errno;
		print_err("Unable to delete drive", argv[1], iocd.stmf_error);
	}
	ret2 = manage_persist(c.drive_guid, NULL, B_FALSE);
	if (ret2 == 0)
		return (0);

	if (ret2 == ENOENT) {
		if (ret == 0)
			return (0);
		print_err("Unable to delete drive", argv[1], iocd.stmf_error);
		return (ret2);
	}
	H("Failed to remove drive from persistant database\n");

	return (ret2);
}

int
load_media(int argc, char **argv)
{
	int ret;
	stt_load_unload_media_t c;

	if (argc != 3) {
		H("Invalid arguments\n");
		usage();
	}
	bzero(&c, sizeof (c));
	strncpy(c.media_file, argv[1], 255);
	if (argv[2][0] == '/') {
		if (path_to_guid(argv[2], c.guid)) {
			fprintf(stderr, "Invalid drive specified %s\n",
			    argv[2]);
			exit(1);
		}
	} else if (!str_to_guid(argv[2], c.guid)) {
		fprintf(stderr, "Invalid guid specified %s\n", argv[2]);
		exit(1);
	}
	bzero(&iocd, sizeof(iocd));
	iocd.stmf_version = STMF_VERSION_1;
	iocd.stmf_ibuf_size = sizeof(c);
	iocd.stmf_ibuf = (uint64_t)&c;
	ret = ioctl(sttfd, STT_IOC_LOAD_MEDIA, &iocd);
	if (ret < 0) {
		ret = errno;
		print_err("Unable to load media", argv[1], iocd.stmf_error);
	}

	return (ret);
}

int
unload_media(int argc, char **argv)
{
	int ret;
	int force = 0;
	stt_load_unload_media_t c;

unload_again:
	if (argc < 2) {
		H("No GUID specified\n");
		usage();
	}
	if (strcmp(argv[1], "-f") == 0) {
		force = 1;
		--argc; ++argv;
		goto unload_again;
	}
	bzero(&c, sizeof (c));
	if (force) {
		c.force_unload = 1;
	}
	if (argv[1][0] == '/') {
		if (path_to_guid(argv[1], c.guid)) {
			fprintf(stderr, "Invalid drive specified %s\n",
			    argv[1]);
			exit(1);
		}
	} else if (!str_to_guid(argv[1], c.guid)) {
		fprintf(stderr, "Invalid guid specified %s\n", argv[1]);
		exit(1);
	}
	bzero(&iocd, sizeof(iocd));
	iocd.stmf_version = STMF_VERSION_1;
	iocd.stmf_ibuf_size = sizeof(c);
	iocd.stmf_ibuf = (uint64_t)&c;
	ret = ioctl(sttfd, STT_IOC_UNLOAD_MEDIA, &iocd);
	if (ret < 0) {
		ret = errno;
		print_err("Unable to unload media", argv[1], iocd.stmf_error);
	}

	return (ret);
}

int
init_media(int argc, char **argv)
{
	stt_media_init_info_t *mi;
	int ret;
	uint32_t s = 0;

init_again:;
	if (argc < 2) {
		H("No Media specified\n");
		usage();
	}
	if (argc > 2) {
		if (strcmp(argv[1], "-s") != 0) {
			H("Unknown option\n");
			usage();
		}

		s = atoi(argv[2]);
		if ((s == 0) || (s & 0x7F)) {
			H("Invalid metadata size. Should be non-zero and a"
			    " multiple of 128\n");
			exit(1);
		}
		s *= 1024;
		argc -= 2;
		argv += 2;
		goto init_again;
	} else {
		if (s == 0)
			s = STT_DEFAULT_MEDIA_META_SIZE;
	}
	mi = malloc(sizeof (*mi));
	if (mi == NULL) {
		H("Memory allocation failure\n");
		exit(1);
	}
	bzero(mi, sizeof (*mi));
	mi->meta_size = s;
	strncpy(mi->media_file_name, argv[1], 255);
	bzero(&iocd, sizeof(iocd));
	iocd.stmf_version = STMF_VERSION_1;
	iocd.stmf_ibuf_size = sizeof (*mi);
	iocd.stmf_ibuf = (uint64_t)mi;
	ret = ioctl(sttfd, STT_IOC_INIT_MEDIA, &iocd);
	free(mi);
	if (ret < 0) {
		ret = errno;
		print_err("Unable to initialize media", argv[1],
		    iocd.stmf_error);
	}

	return (ret);
}

int
drive_info(int argc, char **argv)
{
	int ret, i;
	stt_drive_info_t *di;
	stt_partition_info_t *pi;
	stt_lobj_t *slob;
	int verbose = 0;
	uint8_t guid[16];
	uint32_t asz;

di_again:
	if (argc < 2) {
		H("No GUID specified\n");
		usage();
	}
	if (strcmp(argv[1], "-v") == 0) {
		verbose = 1;
		--argc; ++argv;
		goto di_again;
	}
	di = malloc(sizeof (*di));
	if (di == NULL) {
		H("Memory allocation failure\n");
		exit(1);
	}
	if (argv[1][0] == '/') {
		if (path_to_guid(argv[1], guid)) {
			fprintf(stderr, "Invalid drive specified %s\n",
			    argv[1]);
			free(di);
			exit(1);
		}
	} else if (!str_to_guid(argv[1], guid)) {
		fprintf(stderr, "Invalid guid specified %s\n", argv[1]);
		free(di);
		exit(1);
	}
	bzero(&iocd, sizeof(iocd));
	iocd.stmf_version = STMF_VERSION_1;
	iocd.stmf_ibuf_size = 16;
	iocd.stmf_ibuf = (uint64_t)guid;
	iocd.stmf_obuf_size = sizeof (*di);
	iocd.stmf_obuf = (uint64_t)di;
	ret = ioctl(sttfd, STT_IOC_GET_DRIVE_INFO, &iocd);
	if (ret < 0) {
		ret = errno;
		print_err("Unable to get drive info for drive",
		    argv[1], iocd.stmf_error);
		free(di);
		exit(1);
	}
	guid_to_str(guid, g_str);
	printf("Drive : %s\n", di->meta_file_name);
	printf("                  GUID : %s\n", g_str);
	printf("               BlkSize : %d\n", di->cur_blksize);
	printf("          Driver Flags : %x\n", di->os_flags);
	printf("                 Media : %s\n", di->media_file_name[0] ?
		    			di->media_file_name : "<not present>");
	if ((di->os_flags & 0x10) == 0) {
		free(di);
		return(0);
	}
	printf("    Current Filemark # : %d\n", di->cur_slob_num);
	printf("        Current Offset : %d\n", di->cur_slob_off);
	if (!verbose) {
		free(di);
		return (0);
	}
	pi = malloc(STT_MEDIA_PAR_INFO_SIZE);
	if (pi == NULL) {
		H("Memory allocation failure\n");
		free(di);
		exit(1);
	}
	bzero(&iocd, sizeof(iocd));
	iocd.stmf_version = STMF_VERSION_1;
	iocd.stmf_ibuf_size = 16;
	iocd.stmf_ibuf = (uint64_t)guid;
	iocd.stmf_obuf_size = STT_MEDIA_PAR_INFO_SIZE;
	iocd.stmf_obuf = (uint64_t)pi;
	ret = ioctl(sttfd, STT_IOC_PARTITION_INFO, &iocd);
	if (ret < 0) {
		ret = errno;
		print_err("Unable to get partition info for drive",
		    argv[1], iocd.stmf_error);
		free(di);
		free(pi);
		exit(1);
	}
	asz = pi->spi_alloc_size;
	free(pi);
	pi = malloc(asz);
	if (pi == NULL) {
		H("Memory allocation failure\n");
		free(di);
		exit(1);
	}
	bzero(&iocd, sizeof(iocd));
	iocd.stmf_version = STMF_VERSION_1;
	iocd.stmf_ibuf_size = 16;
	iocd.stmf_ibuf = (uint64_t)guid;
	iocd.stmf_obuf_size = asz;
	iocd.stmf_obuf = (uint64_t)pi;
	ret = ioctl(sttfd, STT_IOC_PARTITION_INFO, &iocd);
	if (ret < 0) {
		ret = errno;
		print_err("Unable to get partition info for drive",
		    argv[1], iocd.stmf_error);
		free(di);
		free(pi);
		exit(1);
	}
	pi->spi_slobs = (stt_lobj_t *)
	    GET_BYTE_OFFSET(pi, STT_MEDIA_PAR_INFO_SIZE);
	printf("  Partition Info:\n");
	printf("  File #    Start       Valid Size      size\n");
	printf("  ------    -----       ----------      ----\n");
	for (i = 0; i < pi->spi_num_slobs; i++) {
		slob = &pi->spi_slobs[i];
		printf("  %-4d      %-10lld  %-010lld      %-010lld %s\n", i,
		    slob->slob_start_addr, slob->slob_valid_data_size,
		    slob->slob_max_size, i == di->cur_slob_num ? " (Current)" :
		    " ");
	}

	free(di);
	free(pi);
	return (0);
}

void
check_version()
{
	uint32_t v;
	uint8_t m, n;

	bzero(&iocd, sizeof(iocd));
	iocd.stmf_version = STMF_VERSION_1;
	iocd.stmf_obuf_size = 4;
	iocd.stmf_obuf = (uint64_t)(&v);
	if (ioctl(sttfd, STT_IOC_GET_DRIVER_VERSION, &iocd) < 0) {
		print_err("Unable to get driver version", 0,
		    iocd.stmf_error);
		exit(1);
	}

	m = v >> 24;
	n = v >> 16;
	if ((m != STT_VER_MAJOR) || (n != STT_VER_MINOR)) {
		fprintf(stderr, "Driver Version mismatch: Expecting %d.%d "
		    "But got %d.%d\n", STT_VER_MAJOR, STT_VER_MINOR, m, n);
		H("Please use sttadm and stt driver from the same package\n");
		exit(1);
	}
}

int
main(int argc, char **argv)
{
	if (argc < 2)
		usage();

	sttfd = open(STTDEV, O_RDONLY);
	if (sttfd < 0) {
		fprintf(stderr, "Unable to open stt driver : %s\n",
		    strerror(errno));
		exit(1);
	}
	check_version();

	if ((strcmp(argv[1], "help") == 0) || (strcmp(argv[1], "-?") == 0)) {
		usage();
	}

	if (strcmp(argv[1], "list-drives") == 0)
		return(list_drives(--argc, ++argv));
	if (strcmp(argv[1], "create-drive") == 0)
		return(create_drive(--argc, ++argv));
	if (strcmp(argv[1], "import-drive") == 0)
		return(import_drive(--argc, ++argv));
	if (strcmp(argv[1], "delete-drive") == 0)
		return(delete_drive(--argc, ++argv));
	if (strcmp(argv[1], "load-media") == 0)
		return(load_media(--argc, ++argv));
	if (strcmp(argv[1], "unload-media") == 0)
		return(unload_media(--argc, ++argv));
	if (strcmp(argv[1], "init-media") == 0)
		return(init_media(--argc, ++argv));
	if (strcmp(argv[1], "drive-info") == 0)
		return(drive_info(--argc, ++argv));

	fprintf(stderr, "Unknown cmd %s\n", argv[1]);
	exit(1);
}
