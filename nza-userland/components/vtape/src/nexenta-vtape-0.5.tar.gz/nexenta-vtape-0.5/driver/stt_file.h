/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License (the "License").
 * You may not use this file except in compliance with the License.
 *
 * You can obtain a copy of the license at usr/src/OPENSOLARIS.LICENSE
 * or http://www.opensolaris.org/os/licensing.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at usr/src/OPENSOLARIS.LICENSE.
 * If applicable, add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your own identifying
 * information: Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 */

/*
 * Copyright 2010 Nexenta Systems.  All rights reserved.
 * Use is subject to license terms.
 */

#ifndef	_STT_FILE_H_
#define	_STT_FILE_H_

typedef struct stt_file {
	char		*f_name;
	uint32_t	f_flags;
	int		f_oflag;
	uint64_t	f_size;
	vnode_t		*f_vp;
} stt_file_t;

/*
 * File flags
 */
#define	STTF_VREG			0x0001
#define	STTF_VCHR			0x0002
#define	STTF_VBLK			0x0004
#define	STTF_READ_ONLY			0x0008
#define	STTF_SYNC_WRITE			0x0010
#define	STTF_DKIOFLUSH_NOT_SUPPORTED	0x0020

stt_file_t *stt_file_open(char *name, int ro, int *err);
void stt_file_close(stt_file_t *sf);
int stt_file_pread(stt_file_t *sf, uint8_t *buf, uint64_t off, uint64_t size,
    int *err);
int stt_file_pwrite(stt_file_t *sf, uint8_t *buf, uint64_t off,
    uint64_t sz, int *err);
int stt_flush_write_cache(stt_file_t *sf, int fsync_done);

#endif	/* _STT_FILE_H_ */
