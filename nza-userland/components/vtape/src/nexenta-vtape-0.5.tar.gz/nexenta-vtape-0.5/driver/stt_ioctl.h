/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License (the "License").
 * You may not use this file except in compliance with the License.
 *
 * You can obtain a copy of the license at usr/src/OPENSOLARIS.LICENSE
 * or http://www.opensolaris.org/os/licensing.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at usr/src/OPENSOLARIS.LICENSE.
 * If applicable, add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your own identifying
 * information: Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 */

/*
 * Copyright 2010 Nexenta Systems.  All rights reserved.
 * Use is subject to license terms.
 */

#ifndef	_STT_IOCTL_H_
#define	_STT_IOCTL_H_

#define	STT_VER_MAJOR		1
#define	STT_VER_MINOR		1

/*
 * STT error codes.
 */
#define	STT_ERR_PATH_NOT_ABSOLUTE		1
#define	STT_ERR_FILE_LOOKUP_FAILED		2
#define	STT_ERR_WRONG_FILE_TYPE			3
#define	STT_ERR_FILE_OPEN_FAILED		4
#define	STT_ERR_GETATTR_FAILED			5
#define	STT_ERR_DRIVE_ALREADY_REGISTERED	6
#define	STT_ERR_META_FILE_CORRUPT		7
#define	STT_ERR_VERSION_MISMATCH		8
#define	STT_ERR_GUID_ALREADY_REGISTERED		9
#define	STT_ERR_STMF_REGISTER_FAILED		10
#define	STT_ERR_DRIVE_NOT_FOUND			11
#define	STT_ERR_TASKS_PENDING			12
#define	STT_ERR_MEDIA_ALREADY_LOADED		13
#define	STT_ERR_NO_MEDIA			14
#define	STT_ERR_MEDIUM_REMOVAL_PREVENTED	15
#define	STT_ERR_LU_BUSY				16
#define	STT_ERR_STATE_TRANSITION_INPROGRESS	17
#define	STT_ERR_LU_OFFLINE_FAILED		18
#define	STT_ERR_LU_OFFLINE_TIMED_OUT		19
#define	STT_ERR_LU_STMF_DEREGISTER_FAILED	20
#define	STT_ERR_MEDIUM_NOT_INITIALIZED		21
#define	STT_ERR_MEDIUM_VERSION_MISMATCH		22
#define	STT_ERR_MEDIUM_CORRUPTED		23
#define	STT_ERR_STMF_DEREGISTER_FAILED		24
#define	STT_ERR_MEDIA_TOO_SMALL			25
#define	STT_ERR_META_SIZE_INVALID		26
#define	STT_MAX_ERR				27

#define STT_ERR_STRS	{ \
	"", \
	"File path does not begin with /", \
	"File not found", \
	"Incorrect file type", \
	"Unable to open file", \
	"Unable to read file attributes", \
	"Drive already registered", \
	"Metadata has been corrupted", \
	"Metadata version mismatch", \
	"GUID is already registered", \
	"Unable to register with STMF", \
	"Unable to find drive", \
	"Drive has active I/O", \
	"Media already loaded", \
	"Medium not present", \
	"Medium removal prevented", \
	"Logical unit is busy", \
	"LU is undergoing state transition", \
	"failed to offline the device", \
	"Device offline timed out", \
	"Unable to deregister with STMF", \
	"Medium not initialized", \
	"Medium is not initialized with currently supported version", \
	"Metadata on the medium is corrupted", \
	"STMF deregister failed", \
	"Medium size is too small", \
	"Invalid metadata size", \
	"" \
}

#define	STT_DEFAULT_MEDIA_META_SIZE	(256 * 1024)
#define	STT_MEDIA_PAR_INFO_SIZE		1024

#if 0
#define	STT_MEDIA_MAX_SLOBS	\
    ((STT_MEDIA_META_SIZE - STT_MEDIA_PAR_INFO_SIZE)/sizeof (stt_lobj_t))
#define	STT_MIN_MEDIA_SIZE		(STT_MEDIA_META_SIZE + (1024 * 1024))
#endif

typedef struct stt_lobj {
	uint64_t	slob_rsvd;	/* will always be zero */
	uint64_t	slob_start_addr;
	uint64_t	slob_valid_data_size;
	uint64_t	slob_max_size;
} stt_lobj_t;

typedef struct stt_partition_info {
	uint64_t		spi_stt_magic;
	uint8_t			spi_major;
	uint8_t			spi_minor;
	uint8_t			spi_dbg_ver;
	uint8_t			spi_rsvd;
	uint32_t		spi_alloc_size;
	uint32_t		spi_num_slobs;
	uint32_t		spi_max_slobs;
	uint64_t		spi_media_size;
	stt_lobj_t		*spi_slobs;
} stt_partition_info_t;

/*
 * IOCTL cmds
 */
#define	STT_IOC_CREATE_DRIVE		1
#define	STT_IOC_IMPORT_DRIVE		2
#define	STT_IOC_DELETE_DRIVE		3
#define	STT_IOC_LIST_DRIVES		4
#define	STT_IOC_GET_DRIVE_PROPS		5
#define	STT_IOC_LOAD_MEDIA		6
#define	STT_IOC_UNLOAD_MEDIA		7
#define	STT_IOC_INIT_MEDIA		8
#define	STT_IOC_GET_DRIVE_LIST		9
#define	STT_IOC_GET_DRIVE_INFO		10
#define	STT_IOC_PARTITION_INFO		11
#define	STT_IOC_GET_DRIVE_GUID		12
#define	STT_IOC_GET_DRIVER_VERSION	13

typedef struct stt_create_import_drive {
	uint32_t	ignore_media:1;	/* Upon import */
	uint32_t	rsvd;
	uint8_t		ret_guid[16];
	char		meta_file[256];
} stt_create_import_drive_t;

typedef struct stt_delete_drive {
	uint32_t	rsvd;	/* Unused bits et to zero */
	uint32_t	rsvd2;
	uint8_t		drive_guid[16];
} stt_delete_drive_t;

typedef struct stt_drive_properties {
	uint32_t	media_loaded:1,
			meta_media_loaded:1;
	uint32_t	rsvd;
	uint8_t		guid[16];
	char		meta_file[256];
	char		media_file[256];
	uint64_t	media_size;
} stt_drive_properties_t;

typedef struct stt_media_init_info {
	uint32_t	rsvd;
	uint32_t	meta_size;
	char		media_file_name[256];
} stt_media_init_info_t;

typedef struct stt_load_unload_media {
	uint32_t	use_alt_size:1,
			no_meta_update:1,
			force_unload:1;
	uint32_t	rsvd;
	uint8_t		guid[16];
	uint64_t	media_alt_size;
	char		media_file[256]; /* only during loading */
} stt_load_unload_media_t;

typedef struct stt_drive_info {
	char		meta_file_name[256];
	char		media_file_name[256];
	uint8_t		guid[16];
	uint32_t	cur_blksize;
	uint32_t	cur_slob_num;
	uint32_t	cur_slob_off;
	uint16_t	cur_stmf_state;
	uint16_t	cur_state_not_acked;
	uint32_t	ntasks_needing_media;
	uint32_t	os_flags;
} stt_drive_info_t;

#endif	/* _STT_IOCTL_H_ */
