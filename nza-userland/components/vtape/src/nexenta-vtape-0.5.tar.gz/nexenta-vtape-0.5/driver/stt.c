/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License (the "License").
 * You may not use this file except in compliance with the License.
 *
 * You can obtain a copy of the license at usr/src/OPENSOLARIS.LICENSE
 * or http://www.opensolaris.org/os/licensing.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at usr/src/OPENSOLARIS.LICENSE.
 * If applicable, add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your own identifying
 * information: Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 */

/*
 * Copyright 2010 Nexenta Systems.  All rights reserved.
 * Use is subject to license terms.
 */

#include <sys/conf.h>
#include <sys/file.h>
#include <sys/ddi.h>
#include <sys/sunddi.h>
#include <sys/modctl.h>
#include <sys/scsi/scsi.h>
#include <sys/scsi/impl/scsi_reset_notify.h>
#include <sys/disp.h>
#include <sys/byteorder.h>
#include <sys/pathname.h>
#include <sys/atomic.h>
#include <sys/nvpair.h>
#include <sys/fs/zfs.h>
#include <sys/sdt.h>
#include <sys/dkio.h>

#include <sys/stmf.h>
#include <sys/lpif.h>
#include <sys/stmf_ioctl.h>
#include "stt_file.h"
#include "stt.h"
#include "stt_ioctl.h"

static int stt_getinfo(dev_info_t *dip, ddi_info_cmd_t cmd, void *arg,
    void **result);
static int stt_attach(dev_info_t *dip, ddi_attach_cmd_t cmd);
static int stt_detach(dev_info_t *dip, ddi_detach_cmd_t cmd);
static int stt_open(dev_t *devp, int flag, int otype, cred_t *credp);
static int stt_close(dev_t dev, int flag, int otype, cred_t *credp);
static int stt_ioctl(dev_t dev, int cmd, intptr_t data, int mode,
    cred_t *credp, int *rval);
int stt_unlock_lu_and_return(int errno, int stt_err, int *err_ret,
    stt_lu_t *slu);
int stt_import_meta(stt_create_import_drive_t *m, int *err);
int stt_create_meta(stt_create_import_drive_t *m, int *err);
int stt_delete_drive(stt_delete_drive_t *d, int *err);
int stt_load_media(stt_load_unload_media_t *slm, int *err);
int stt_load_media_slu_locked(stt_lu_t *slu,
    stt_load_unload_media_t *slm, int *err);
int stt_unload_media(stt_load_unload_media_t *slm, int *err);
int stt_unload_media_slu_locked(stt_lu_t *slu,
    stt_load_unload_media_t *slm, int *err);
int stt_init_media(stt_media_init_info_t *mi, int *err);
int stt_load_media_meta(stt_file_t *sf, stt_lu_t *slu, int *err);
int stt_read_drive_info(uint8_t *guid, stt_drive_info_t *di, int *err);
int stt_read_partition_info(uint8_t *guid, uint8_t *pi, uint32_t sz, int *err);
void stt_lp_cb(stmf_lu_provider_t *lp, int cmd, void *arg, uint32_t flags);

static stmf_lu_provider_t *stt_lp;
static kmutex_t		stt_global_lock;
static dev_info_t	*stt_dip;
static char stt_name[] = "stt";
static int		stt_lu_count = 0;
stt_lu_t		*stt_lu_list = NULL;
char			stt_vid[] = "COMSTAR ";
int			stt_allow_modunload = 0;

static struct cb_ops stt_cb_ops = {
	stt_open,			/* open */
	stt_close,			/* close */
	nodev,				/* strategy */
	nodev,				/* print */
	nodev,				/* dump */
	nodev,				/* read */
	nodev,				/* write */
	stt_ioctl,			/* ioctl */
	nodev,				/* devmap */
	nodev,				/* mmap */
	nodev,				/* segmap */
	nochpoll,			/* chpoll */
	ddi_prop_op,			/* cb_prop_op */
	0,				/* streamtab */
	D_NEW | D_MP,			/* cb_flag */
	CB_REV,				/* rev */
	nodev,				/* aread */
	nodev				/* awrite */
};

static struct dev_ops stt_ops = {
	DEVO_REV,
	0,
	stt_getinfo,
	nulldev,		/* identify */
	nulldev,		/* probe */
	stt_attach,
	stt_detach,
	nodev,			/* reset */
	&stt_cb_ops,
	NULL,			/* bus_ops */
	NULL			/* power */
};

char stt_mod_infostr[32];

static struct modldrv modldrv = {
	&mod_driverops,
	stt_mod_infostr,
	&stt_ops
};

static struct modlinkage modlinkage = {
	MODREV_1,
	&modldrv,
	NULL
};

int
_init(void)
{
	int ret;

	sprintf(stt_mod_infostr, "COMSTAR Tape %d.%d", STT_VER_MAJOR,
	    STT_VER_MINOR);
	ret = mod_install(&modlinkage);
	if (ret)
		return (ret);
	stt_lp = (stmf_lu_provider_t *)stmf_alloc(STMF_STRUCT_LU_PROVIDER,
	    0, 0);
	stt_lp->lp_lpif_rev = LPIF_REV_2;
	stt_lp->lp_instance = 0;
	stt_lp->lp_name = stt_name;
	stt_lp->lp_cb = stt_lp_cb;

	if (stmf_register_lu_provider(stt_lp) != STMF_SUCCESS) {
		(void) mod_remove(&modlinkage);
		stmf_free(stt_lp);
		return (EINVAL);
	}
	mutex_init(&stt_global_lock, NULL, MUTEX_DRIVER, NULL);
	return (0);
}

int
_fini(void)
{
	int ret;

	if (!stt_allow_modunload)
		return (EBUSY);
	mutex_enter(&stt_global_lock);
	while (stt_lu_list != NULL) {
		stt_delete_drive_t d;
		int err;

		bzero(&d, sizeof (d));
		bcopy(stt_lu_list->slu_device_id + 4, d.drive_guid, 16);
		mutex_exit(&stt_global_lock);
		ret = stt_delete_drive(&d, &err);
		if (ret != 0) {
			cmn_err(CE_WARN, "Unable to unload stt. Drive could "
			    "not be deleted. err %d", err);
			return (EBUSY);
		}
		mutex_enter(&stt_global_lock);
	}
	mutex_exit(&stt_global_lock);
	if (stmf_deregister_lu_provider(stt_lp) != STMF_SUCCESS)
		return (EBUSY);
	ret = mod_remove(&modlinkage);
	if (ret != 0) {
		(void) stmf_register_lu_provider(stt_lp);
		return (ret);
	}
	stmf_free(stt_lp);
	mutex_destroy(&stt_global_lock);
	return (0);
}

int
_info(struct modinfo *modinfop)
{
	return (mod_info(&modlinkage, modinfop));
}

/* ARGSUSED */
static int
stt_getinfo(dev_info_t *dip, ddi_info_cmd_t cmd, void *arg, void **result)
{
	switch (cmd) {
	case DDI_INFO_DEVT2DEVINFO:
		*result = stt_dip;
		break;
	case DDI_INFO_DEVT2INSTANCE:
		*result = (void *)(uintptr_t)ddi_get_instance(stt_dip);
		break;
	default:
		return (DDI_FAILURE);
	}

	return (DDI_SUCCESS);
}

static int
stt_attach(dev_info_t *dip, ddi_attach_cmd_t cmd)
{
	char *p;
	int l;

	switch (cmd) {
	case DDI_ATTACH:
		stt_dip = dip;

		if (ddi_create_minor_node(dip, "admin", S_IFCHR, 0,
		    DDI_NT_STMF_LP, 0) != DDI_SUCCESS) {
			break;
		}
		if (ddi_prop_lookup_string(DDI_DEV_T_ANY, dip, 0,
		    "stt_vendor_id", &p) == DDI_PROP_SUCCESS) {
			bcopy("        ", stt_vid, 8);
			l = strlen(p);
			l = l > 8 ? 8 : l;
			bcopy(p, stt_vid, l);
			ddi_prop_free(p);
		}
		ddi_report_dev(dip);
		return (DDI_SUCCESS);
	}

	return (DDI_FAILURE);
}

static int
stt_detach(dev_info_t *dip, ddi_detach_cmd_t cmd)
{
	switch (cmd) {
	case DDI_DETACH:
		ddi_remove_minor_node(dip, 0);
		return (DDI_SUCCESS);
	}

	return (DDI_FAILURE);
}

/* ARGSUSED */
static int
stt_open(dev_t *devp, int flag, int otype, cred_t *credp)
{
	if (otype != OTYP_CHR)
		return (EINVAL);
	return (0);
}

/* ARGSUSED */
static int
stt_close(dev_t dev, int flag, int otype, cred_t *credp)
{
	return (0);
}

/* ARGSUSED */
static int
stt_ioctl(dev_t dev, int cmd, intptr_t data, int mode,
	cred_t *credp, int *rval)
{
	stmf_iocdata_t		*iocd;
	stt_lu_t		*slu;
	void			*ibuf	= NULL;
	void			*obuf	= NULL;
	int			i;
	int			ret;
	int			copy_ibuf = 0;

	if (drv_priv(credp) != 0) {
		return (EPERM);
	}

	ret = stmf_copyin_iocdata(data, mode, &iocd, &ibuf, &obuf);
	if (ret)
		return (ret);
	iocd->stmf_error = 0;

	switch (cmd) {
	case STT_IOC_CREATE_DRIVE:
		if (iocd->stmf_ibuf_size != sizeof(stt_create_import_drive_t)) {
			ret = EINVAL;
			break;
		}
		ret = stt_create_meta((stt_create_import_drive_t *)ibuf,
		    (int *)&iocd->stmf_error);
		if (ret)
			break;
		/* FALLTHROUGH */
	case STT_IOC_IMPORT_DRIVE:
		if (iocd->stmf_ibuf_size != sizeof(stt_create_import_drive_t)) {
			ret = EINVAL;
			break;
		}
		ret = stt_import_meta((stt_create_import_drive_t *)ibuf,
		    (int *)&iocd->stmf_error);
		copy_ibuf = 1;
		break;
	case STT_IOC_DELETE_DRIVE:
		if (iocd->stmf_ibuf_size != sizeof(stt_delete_drive_t)) {
			ret = EINVAL;
			break;
		}
		ret = stt_delete_drive((stt_delete_drive_t *)ibuf,
		    (int *)&iocd->stmf_error);
		break;
	case STT_IOC_LOAD_MEDIA:
		if (iocd->stmf_ibuf_size != sizeof(stt_load_unload_media_t)) {
			ret = EINVAL;
			break;
		}
		ret = stt_load_media((stt_load_unload_media_t *)ibuf,
		    (int *)&iocd->stmf_error);
		break;
	case STT_IOC_UNLOAD_MEDIA:
		if (iocd->stmf_ibuf_size != sizeof(stt_load_unload_media_t)) {
			ret = EINVAL;
			break;
		}
		ret = stt_unload_media((stt_load_unload_media_t *)ibuf,
		    (int *)&iocd->stmf_error);
		break;
	case STT_IOC_INIT_MEDIA:
		if (iocd->stmf_ibuf_size != sizeof (stt_media_init_info_t)) {
			ret = EINVAL;
			break;
		}
		ret = stt_init_media((stt_media_init_info_t *)ibuf,
		    (int *)&iocd->stmf_error);
		break;
	case STT_IOC_GET_DRIVE_INFO:
		if ((iocd->stmf_ibuf_size != 16) ||
		    (iocd->stmf_obuf_size != sizeof (stt_drive_info_t))) {
			ret = EINVAL;
			break;
		}
		if (obuf == NULL) {
			printf("obuf is NULL, iocd=%p, ibuf=%p, obuf=%p\n",
			    iocd, ibuf, obuf);
			delay(2);
			debug_enter("obuf is NULL");
			ret = EINVAL;
			break;
		}
		ret = stt_read_drive_info(ibuf, (stt_drive_info_t*)obuf,
		    (int *)&iocd->stmf_error);
		break;
	case STT_IOC_PARTITION_INFO:
		if ((iocd->stmf_ibuf_size != 16) ||
		    (iocd->stmf_obuf_size < STT_MEDIA_PAR_INFO_SIZE)) {
			ret = EINVAL;
			break;
		}
		ret = stt_read_partition_info(ibuf, obuf, iocd->stmf_obuf_size,
		    (int *)&iocd->stmf_error);
		break;
	case STT_IOC_GET_DRIVE_LIST:
		mutex_enter(&stt_global_lock);
		iocd->stmf_obuf_max_nentries = stt_lu_count;
		iocd->stmf_obuf_nentries = min((iocd->stmf_obuf_size >> 4),
		    stt_lu_count);
		for (slu = stt_lu_list, i = 0; slu &&
		    (i < iocd->stmf_obuf_nentries); i++, slu = slu->slu_next) {
			bcopy(slu->slu_device_id + 4,
			    &(((uint8_t *)obuf)[i << 4]), 16);
		}
		mutex_exit(&stt_global_lock);
		ret = 0;
		iocd->stmf_error = 0;
		break;
	case STT_IOC_GET_DRIVE_GUID:
		if ((iocd->stmf_ibuf_size == 0) ||
		    (iocd->stmf_obuf_size != 16)) {
			ret = EINVAL;
			break;
		}
		((char *)ibuf)[iocd->stmf_ibuf_size - 1] = 0;
		ret = ENOENT;
		iocd->stmf_error = STT_ERR_DRIVE_NOT_FOUND;
		mutex_enter(&stt_global_lock);
		for (slu = stt_lu_list; slu; slu = slu->slu_next) {
			if (strcmp(slu->slu_meta_file->f_name, ibuf) == 0) {
				bcopy(slu->slu_device_id + 4, obuf, 16);
				ret = 0;
				iocd->stmf_error = 0;
				break;
			}
		}
		mutex_exit(&stt_global_lock);
		break;
	case STT_IOC_GET_DRIVER_VERSION:
		if (iocd->stmf_obuf_size != sizeof(uint32_t)) {
			ret = EINVAL;
			break;
		}
		*((uint32_t *)obuf) = ((uint32_t)STT_VER_MAJOR) << 24;
		*((uint32_t *)obuf) |= ((uint32_t)STT_VER_MINOR) << 16;
		ret = 0;
		break;
	default:
		ret = ENOTTY;
	}

	if (copy_ibuf && (iocd->stmf_obuf_size >= iocd->stmf_ibuf_size))
		bcopy (ibuf, obuf, iocd->stmf_ibuf_size);
	if (ret == 0) {
		ret = stmf_copyout_iocdata(data, mode, iocd, obuf);
	} else if (iocd->stmf_error) {
		(void) stmf_copyout_iocdata(data, mode, iocd, obuf);
	}
	if (obuf) {
		kmem_free(obuf, iocd->stmf_obuf_size);
		obuf = NULL;
	}
	if (ibuf) {
		kmem_free(ibuf, iocd->stmf_ibuf_size);
		ibuf = NULL;
	}
	kmem_free(iocd, sizeof (stmf_iocdata_t));
	return (ret);
}

void
stt_lp_cb(stmf_lu_provider_t *lp, int cmd, void *arg, uint32_t flags)
{
	nvpair_t			*np;
	char				*s;
	stt_create_import_drive_t	 *m;
	int				err_ret;
	int				iret;

	if ((cmd != STMF_PROVIDER_DATA_UPDATED) || (arg == NULL)) {
		return;
	}

	if ((flags & (STMF_PCB_STMF_ONLINING | STMF_PCB_PREG_COMPLETE)) == 0) {
		return;
	}

	np = NULL;
	m = (stt_create_import_drive_t *)kmem_zalloc(sizeof (*m), KM_SLEEP);
	while ((np = nvlist_next_nvpair((nvlist_t *)arg, np)) != NULL) {
		if (nvpair_type(np) != DATA_TYPE_STRING) {
			continue;
		}
		if (nvpair_value_string(np, &s) != 0) {
			continue;
		}
		(void) strcpy(m->meta_file, s);
		iret = stt_import_meta(m, &err_ret);
		if (iret) {
			stmf_trace(0, "stt_lp_cb: import_lu failed, ret = %d, "
			    "err_ret = %d", iret, err_ret);
		}
	}
	kmem_free(m, sizeof (*m));
}

int
stt_unlock_lu_and_return(int errno, int stt_err, int *err_ret, stt_lu_t *slu)
{
	*err_ret = stt_err;
	mutex_enter(&slu->slu_lock);
	slu->slu_flags &= ~SLUF_LU_BUSY;
	mutex_exit(&slu->slu_lock);
	return (errno);
}

int
stt_create_meta(stt_create_import_drive_t *m, int *err)
{
	int ret;
	stt_file_t *sf = NULL;
	stt_meta_info_t *smi = NULL;
	stt_lu_t *slu;
	uint8_t did[20];

	m->meta_file[255] = 0;
	/* Some sanity checking */
	mutex_enter(&stt_global_lock);
	for (slu = stt_lu_list; slu; slu = slu->slu_next) {
		if (strcmp(m->meta_file, slu->slu_meta_file->f_name) == 0) {
			mutex_exit(&stt_global_lock);
			*err = STT_ERR_DRIVE_ALREADY_REGISTERED;
			return (EIO);
		}
	}
	mutex_exit(&stt_global_lock);

	sf = stt_file_open(m->meta_file, 0, err);
	if (sf == NULL)
		return (EIO);

	did[3] = 16;
	/*
	 * Setting bit 1 (the 2 in 0xE2) in MSB makes it a local adddress
	 * instead of a OUI.
	 */
	stmf_scsilib_uniq_lu_id(0xE25EDA, (scsi_devid_desc_t *)did);
	smi = kmem_zalloc(sizeof (*smi), KM_SLEEP);
	smi->smi_magic = STT_MAGIC;
	smi->smi_major = STT_VER_MAJOR;
	smi->smi_minor = STT_VER_MINOR;
	bcopy(did + 4, smi->smi_guid, 16);

	ret = stt_file_pwrite(sf, (uint8_t *)smi, 0, sizeof (*smi), err);
	stt_file_close(sf);
	kmem_free(smi, sizeof (*smi));

	return (ret);
}

int
stt_import_meta(stt_create_import_drive_t *m, int *err)
{
	stt_file_t *sf = NULL;
	stt_meta_info_t *smi = NULL;
	stt_lu_t *slu = NULL, *t, **ppslu;
	stmf_lu_t *lu = NULL;

	sf = stt_file_open(m->meta_file, 0, err);
	if (sf == NULL)
		goto import_meta_failed;
	smi = kmem_zalloc(sizeof (*smi), KM_SLEEP);
	if (stt_file_pread(sf, (uint8_t *)smi, 0, sizeof (*smi), err))
		goto import_meta_failed;
	if (smi->smi_magic != STT_MAGIC) {
		*err = STT_ERR_META_FILE_CORRUPT;
		goto import_meta_failed;
	}
	if ((smi->smi_major != STT_VER_MAJOR) ||
	    (smi->smi_minor != STT_VER_MINOR)) {
		*err = STT_ERR_VERSION_MISMATCH;
		goto import_meta_failed;
	}
	bcopy(smi->smi_guid, m->ret_guid, 16);

	lu = stmf_alloc(STMF_STRUCT_STMF_LU, sizeof (stt_lu_t), 0);
	slu = (stt_lu_t *)lu->lu_provider_private;
	bzero(slu, sizeof (*slu));
	slu->slu_lu = lu;
	mutex_init(&slu->slu_lock, NULL, MUTEX_DRIVER, NULL);
	slu->slu_meta_file = sf;
	if (smi->smi_flags & SMIF_WRITE_PROTECTED) {
		slu->slu_flags |= SLUF_WRITE_PROTECTED;
	}
	slu->slu_state = STMF_STATE_OFFLINE;
	slu->slu_device_id[0] = 0xf1;
	slu->slu_device_id[1] = 3;
	slu->slu_device_id[2] = 0;
	slu->slu_device_id[3] = 16;
	bcopy(smi->smi_guid, slu->slu_device_id + 4, 16);

	/* Link this LU on the global list */
	mutex_enter(&stt_global_lock);
	slu->slu_flags |= SLUF_LU_BUSY;
	for (t = stt_lu_list; t; t = t->slu_next) {
		if (bcmp(t->slu_device_id, slu->slu_device_id, 20) == 0) {
			mutex_exit(&stt_global_lock);
			*err = STT_ERR_GUID_ALREADY_REGISTERED;
			goto import_meta_failed;
		}
	}
	slu->slu_next = stt_lu_list;
	stt_lu_list = slu;
	stt_lu_count++;
	mutex_exit(&stt_global_lock);

	slu->slu_cur_blksize = 512;

	/* Now register this LU with stmf */
	lu->lu_id = (scsi_devid_desc_t *)slu->slu_device_id;
	lu->lu_alias = slu->slu_meta_file->f_name;
	lu->lu_lp = stt_lp;
	lu->lu_task_alloc = stt_task_alloc;
	lu->lu_new_task = stt_new_task;
	lu->lu_dbuf_xfer_done = stt_dbuf_xfer_done;
	lu->lu_send_status_done = stt_send_status_done;
	lu->lu_task_free = stt_task_free;
	lu->lu_abort = stt_abort;
	lu->lu_ctl = stt_ctl;
	lu->lu_info = stt_info;

	if (stmf_register_lu(lu) != STMF_SUCCESS) {
		*err = STT_ERR_STMF_REGISTER_FAILED;
		mutex_enter(&stt_global_lock);
		for (ppslu = &stt_lu_list; *ppslu;
		    ppslu = &((*ppslu)->slu_next)) {
			if (*ppslu == slu) {
				*ppslu = slu->slu_next;
				stt_lu_count--;
				break;
			}
		}
		mutex_exit(&stt_global_lock);
		goto import_meta_failed;
	}

	if ((m->ignore_media == 0) &&
	    (smi->smi_flags & SMIF_MEDIA_LOADED)) {
		stt_load_unload_media_t *slm;
		int err;

		slm = kmem_zalloc(sizeof (*slm), KM_SLEEP);
		slm->no_meta_update = 1;
		strncpy(slm->media_file, (char *)smi->smi_media_file,
		    sizeof(slm->media_file) - 1);
		bcopy(slu->slu_device_id + 4, slm->guid, 16);
		if (stt_load_media_slu_locked(slu, slm, &err) != 0) {
			cmn_err(CE_WARN,
			    "import_lu:Unable to load media, err=%d", err);
		}
		kmem_free(slm, sizeof (*slm));
	}

	*err = 0;
	mutex_enter(&slu->slu_lock);
	slu->slu_flags &= ~SLUF_LU_BUSY;
	mutex_exit(&slu->slu_lock);
	if (smi)
		kmem_free(smi, sizeof (*smi));
	return (0);

import_meta_failed:
	if (sf)
		stt_file_close(sf);
	if (smi)
		kmem_free(smi, sizeof (*smi));
	if (lu)
		stmf_free(lu);

	return (EIO);
}

int
stt_update_meta(stt_lu_t *slu)
{
	stt_meta_info_t *smi;
	int ret;
	int err;

	ASSERT(slu->slu_meta_file);
	ASSERT(slu->slu_flags & SLUF_LU_BUSY);

	smi = kmem_zalloc(sizeof (*smi), KM_SLEEP);
	smi->smi_magic = STT_MAGIC;
	smi->smi_major = STT_VER_MAJOR;
	smi->smi_minor = STT_VER_MINOR;
	bcopy(slu->slu_device_id + 4, smi->smi_guid, 16);
	if (slu->slu_flags & SLUF_WRITE_PROTECTED)
		smi->smi_flags |= SMIF_WRITE_PROTECTED;
	if (slu->slu_flags & SLUF_ALLOW_MEDIA_ACCESS) {
		smi->smi_flags |= SMIF_MEDIA_LOADED;
		strcpy((char *)smi->smi_media_file,
		    slu->slu_media_file->f_name);
	}
	ret = stt_file_pwrite(slu->slu_meta_file,
	    (uint8_t *)smi, 0, sizeof (*smi), &err);
	(void)stt_flush_write_cache(slu->slu_meta_file, 0);
	kmem_free(smi, sizeof (*smi));
	return (ret);
}

int
stt_delete_drive(stt_delete_drive_t *d, int *err)
{
	stmf_state_change_info_t ssi;
	stt_lu_t *slu;
	stt_lu_t **ppslu;
	int i;

	ssi.st_rflags = STMF_RFLAG_USER_REQUEST;
	ssi.st_additional_info = "stt_delete_lu call (ioctl)";

	mutex_enter(&stt_global_lock);
	for (slu = stt_lu_list; slu; slu = slu->slu_next) {
		if (bcmp(slu->slu_device_id + 4, d->drive_guid, 16) == 0) {
			mutex_enter(&slu->slu_lock);
			if (slu->slu_flags & SLUF_LU_BUSY) {
				mutex_exit(&slu->slu_lock);
				mutex_exit(&stt_global_lock);
				*err = STT_ERR_LU_BUSY;
				return (EIO);
			}
			slu->slu_flags |= SLUF_LU_BUSY;
			mutex_exit(&slu->slu_lock);
			break;
		}
	}
	mutex_exit(&stt_global_lock);
	if (slu == NULL) {
		*err = STT_ERR_DRIVE_NOT_FOUND;
		return (EIO);
	}
	if ((slu->slu_state == STMF_STATE_OFFLINE) &&
	    !slu->slu_state_not_acked) {
		goto do_dereg;
	}

	if ((slu->slu_state != STMF_STATE_ONLINE) ||
	    slu->slu_state_not_acked) {
		return(stt_unlock_lu_and_return(EBUSY,
		    STT_ERR_STATE_TRANSITION_INPROGRESS, err, slu));
	}
	if (stmf_ctl(STMF_CMD_LU_OFFLINE, slu->slu_lu, &ssi) != STMF_SUCCESS) {
		return(stt_unlock_lu_and_return(EBUSY,
		    STT_ERR_LU_OFFLINE_FAILED, err, slu));
	}

	for (i = 0; i < 500; i++) {
		if (slu->slu_state == STMF_STATE_OFFLINE)
			break;
		delay(drv_usectohz(10000));
	}

	if ((slu->slu_state == STMF_STATE_OFFLINE) &&
	    !slu->slu_state_not_acked) {
		goto do_dereg;
	}

	return(stt_unlock_lu_and_return(EBUSY, STT_ERR_LU_OFFLINE_TIMED_OUT,
	    err, slu));

do_dereg:;
	if (stmf_deregister_lu(slu->slu_lu) != STMF_SUCCESS) {
		return(stt_unlock_lu_and_return(EBUSY,
		    STT_ERR_STMF_DEREGISTER_FAILED, err, slu));
	}

	if (slu->slu_flags & SLUF_ALLOW_MEDIA_ACCESS) {
		stt_load_unload_media_t *slm;

		slm = kmem_zalloc(sizeof (*slm), KM_SLEEP);
		slm->no_meta_update = 1;
		bcopy(slu->slu_device_id + 4, slm->guid, 16);
		if (stt_unload_media_slu_locked(slu, slm, err) != 0) {
			/* This should not have happened */
			cmn_err(CE_PANIC,
			    "delete_lu:Unable to unload media, slu=%p, err=%d",
			    slu, *err);
		}
		kmem_free(slm, sizeof (*slm));
	}
	stt_file_close(slu->slu_meta_file);

	mutex_destroy(&slu->slu_lock);
	mutex_enter(&stt_global_lock);
	for (ppslu = &stt_lu_list; *ppslu; ppslu = &((*ppslu)->slu_next)) {
		if (*ppslu == slu) {
			*ppslu = slu->slu_next;	
			stt_lu_count--;
			break;
		}
	}
	mutex_exit(&stt_global_lock);
	stmf_free(slu->slu_lu);
	*err = 0;
	return (0);
}

int
stt_load_media_slu_locked(stt_lu_t *slu, stt_load_unload_media_t *slm, int *err)
{
	stt_file_t *mf = NULL;
	int ret;

	slm->media_file[255] = 0;
	mf = stt_file_open(slm->media_file,
	    slu->slu_flags & SLUF_WRITE_PROTECTED, err);
	if (mf == NULL) {
		return (EIO);
	}
	if ((slu->slu_media_file) ||
	    (slu->slu_flags & SLUF_ALLOW_MEDIA_ACCESS)) {
		stt_file_close(mf);
		mf = NULL;
		*err = STT_ERR_MEDIA_ALREADY_LOADED;
		return (EIO);
	}
	ret = stt_load_media_meta(mf, slu, err);
	if (ret != 0)
		return (ret);

	if (slm->no_meta_update == 0)
		(void)stt_update_meta(slu);
	*err = 0;
	return (0);
}

int
stt_load_media(stt_load_unload_media_t *slm, int *err)
{
	stt_lu_t *slu = NULL;
	int try = 0;
	int ret;

load_again:;
	if (try++ > 10) {
		*err = STT_ERR_LU_BUSY;
		return (EIO);
	}
	mutex_enter(&stt_global_lock);
	for (slu = stt_lu_list; slu; slu = slu->slu_next) {
		if (bcmp(slu->slu_device_id + 4, slm->guid, 16) == 0) {
			mutex_enter(&slu->slu_lock);
			if (slu->slu_flags & SLUF_LU_BUSY) {
				mutex_exit(&slu->slu_lock);
				mutex_exit(&stt_global_lock);
				delay(drv_usectohz(10000));
				goto load_again;
			}
			slu->slu_flags |= SLUF_LU_BUSY;
			mutex_exit(&slu->slu_lock);
			break;
		}
	}
	mutex_exit(&stt_global_lock);
	if (slu == NULL) {
		*err = STT_ERR_DRIVE_NOT_FOUND;
		return (EIO);
	}
	ret = stt_load_media_slu_locked(slu, slm, err);
	mutex_enter(&slu->slu_lock);
	slu->slu_flags &= ~SLUF_LU_BUSY;
	mutex_exit(&slu->slu_lock);
	return (ret);
}

int
stt_unload_media_slu_locked(stt_lu_t *slu, stt_load_unload_media_t *slm,
    int *err)
{
	int ret;
	int try;

	if ((slu->slu_flags & SLUF_ALLOW_MEDIA_ACCESS) == 0) {
		*err = STT_ERR_NO_MEDIA;
		return (EIO);
	}
	if ((slu->slu_flags & SLUF_MEDIUM_REMOVAL_PREVENTED) &&
	    (slm->force_unload == 0)) {
		*err = STT_ERR_MEDIUM_REMOVAL_PREVENTED;
		return (EIO);
	}
	mutex_enter(&slu->slu_lock);
	slu->slu_flags &= ~SLUF_ALLOW_MEDIA_ACCESS;
	mutex_exit(&slu->slu_lock);
	try = 0;
	while ((slu->slu_ntasks_needing_media) && (++try < 1000)) {
		delay(drv_usectohz(10000));
	}
	if (slu->slu_ntasks_needing_media) {
		mutex_enter(&slu->slu_lock);
		slu->slu_flags |= SLUF_ALLOW_MEDIA_ACCESS;
		mutex_exit(&slu->slu_lock);
		*err = STT_ERR_TASKS_PENDING;
		return (EIO);
	}
	mutex_enter(&slu->slu_lock);
	slu->slu_flags &= ~SLUF_MEDIUM_REMOVAL_PREVENTED;
	mutex_exit(&slu->slu_lock);
	stt_file_close(slu->slu_media_file);
	slu->slu_media_file = NULL;
	kmem_free(slu->slu_spi, slu->slu_spi->spi_alloc_size);
	slu->slu_spi = NULL;

	if (slm->no_meta_update == 0)
		(void)stt_update_meta(slu);

	*err = 0;
	return (0);
}

int
stt_unload_media(stt_load_unload_media_t *slm, int *err)
{
	stt_lu_t *slu = NULL;
	int try = 0;
	int ret;

unload_again:;
	if (try++ > 10) {
		*err = STT_ERR_LU_BUSY;
		return (EIO);
	}
	mutex_enter(&stt_global_lock);
	for (slu = stt_lu_list; slu; slu = slu->slu_next) {
		if (bcmp(slu->slu_device_id + 4, slm->guid, 16) == 0) {
			mutex_enter(&slu->slu_lock);
			if (slu->slu_flags & SLUF_LU_BUSY) {
				mutex_exit(&slu->slu_lock);
				mutex_exit(&stt_global_lock);
				delay(drv_usectohz(10000));
				goto unload_again;
			}
			slu->slu_flags |= SLUF_LU_BUSY;
			mutex_exit(&slu->slu_lock);
			break;
		}
	}
	mutex_exit(&stt_global_lock);
	if (slu == NULL) {
		*err = STT_ERR_DRIVE_NOT_FOUND;
		return (EIO);
	}
	ret = stt_unload_media_slu_locked(slu, slm, err);
	mutex_enter(&slu->slu_lock);
	slu->slu_flags &= ~SLUF_LU_BUSY;
	mutex_exit(&slu->slu_lock);
	return (ret);
}

int
stt_init_media(stt_media_init_info_t *mi, int *err)
{
	stt_partition_info_t *spi = NULL;
	stt_file_t *sf;
	stt_lobj_t *slob;
	int sz;
	int ret;

	mi->media_file_name[255] = 0;
	if ((mi->meta_size == 0) || (mi->meta_size & ((128 * 1024) - 1))) {
		*err = STT_ERR_META_SIZE_INVALID;
		return (EIO);
	}
	sf = stt_file_open(mi->media_file_name, 0, err);

	if (sf == NULL)
		return (EIO);
	
	if (sf->f_size < ((uint64_t)mi->meta_size + (128 * 1024))) {
		stt_file_close(sf);
		*err = STT_ERR_MEDIA_TOO_SMALL;
		return (EINVAL);
	}
	sz = STT_MEDIA_PAR_INFO_SIZE + 512;

	spi = kmem_zalloc(sz, KM_SLEEP);
	slob = (stt_lobj_t *)GET_BYTE_OFFSET(spi, STT_MEDIA_PAR_INFO_SIZE);

	spi->spi_stt_magic = STT_MAGIC;
	spi->spi_major = STT_VER_MAJOR;
	spi->spi_minor = STT_VER_MINOR;
	spi->spi_num_slobs = 1;
	spi->spi_max_slobs =
	    (mi->meta_size - STT_MEDIA_PAR_INFO_SIZE)/sizeof (stt_lobj_t);
	spi->spi_media_size = sf->f_size;

	slob->slob_rsvd = 0;
	slob->slob_start_addr = (uint64_t)mi->meta_size;
	slob->slob_valid_data_size = 0;
	slob->slob_max_size = sf->f_size - (uint64_t)mi->meta_size;

	ret = stt_file_pwrite(sf, (uint8_t *)spi, 0, (uint64_t)sz, err);
	(void)stt_flush_write_cache(sf, 0);

	kmem_free(spi, sz);
	stt_file_close(sf);

	return (ret);
}

int
stt_load_media_meta(stt_file_t *sf, stt_lu_t *slu, int *err)
{
	stt_partition_info_t *spi;
	stt_lobj_t *slob;
	stt_it_data_t *it;
	int ret;
	int sz;
	uint64_t cur;
	int i;

	ASSERT (slu->slu_spi == NULL);
	ASSERT (slu->slu_flags & SLUF_LU_BUSY);

	sz = STT_MEDIA_PAR_INFO_SIZE;
	spi = kmem_zalloc(sz, KM_SLEEP);
	if ((ret = stt_file_pread(sf, (uint8_t *)spi, 0,
	    STT_MEDIA_PAR_INFO_SIZE, err)) != 0) {
		goto load_media_meta_done;
	}
	ret = EIO;
	if (spi->spi_stt_magic != STT_MAGIC) {
		*err = STT_ERR_MEDIUM_NOT_INITIALIZED;
		goto load_media_meta_done;
	}
	if ((spi->spi_major != STT_VER_MAJOR) ||
	    (spi->spi_minor != STT_VER_MINOR)) {
		*err = STT_ERR_MEDIUM_VERSION_MISMATCH;
		goto load_media_meta_done;
	}
	if ((spi->spi_num_slobs > spi->spi_max_slobs) ||
	    (spi->spi_num_slobs == 0)) {
		*err = STT_ERR_MEDIUM_CORRUPTED;
		goto load_media_meta_done;
	}

	sz = spi->spi_num_slobs;
	sz *= sizeof (stt_lobj_t);
	sz += STT_MEDIA_PAR_INFO_SIZE + 511;
	sz &= ~511;
	kmem_free(spi, STT_MEDIA_PAR_INFO_SIZE);
	spi = kmem_zalloc(sz, KM_SLEEP);
	if ((ret = stt_file_pread(sf, (uint8_t *)spi, 0, sz, err)) != 0) {
		goto load_media_meta_done;
	}

	spi->spi_alloc_size = sz;
	spi->spi_slobs = (stt_lobj_t *)
	    GET_BYTE_OFFSET(spi, STT_MEDIA_PAR_INFO_SIZE);

	/* Now sanity check all the slobs */
	ret = EIO;
	if ((spi->spi_num_slobs > spi->spi_max_slobs) ||
	    (spi->spi_num_slobs == 0)) {
		*err = STT_ERR_MEDIUM_CORRUPTED;
		goto load_media_meta_done;
	}
	slob = &spi->spi_slobs[0];
	cur = slob->slob_start_addr;
	if ((cur == 0) || (cur & ((128 * 1024) - 1))) {
		*err = STT_ERR_MEDIUM_CORRUPTED;
		goto load_media_meta_done;
	}
	for (i = 0; i < spi->spi_num_slobs; i++) {
		slob = &spi->spi_slobs[i];
		if ((slob->slob_start_addr != cur) ||
		    ((slob->slob_max_size + cur) > spi->spi_media_size) ||
		    (slob->slob_valid_data_size > slob->slob_max_size)) {
			*err = STT_ERR_MEDIUM_CORRUPTED;
			goto load_media_meta_done;
		}
		cur += slob->slob_max_size;
	}
	if (cur != spi->spi_media_size) {
		*err = STT_ERR_MEDIUM_CORRUPTED;
		goto load_media_meta_done;
	}

	/* ALL good */
	ret = 0;
	slu->slu_media_file = sf;
	slu->slu_spi = spi;
	slu->slu_cur_off = 0;
	slu->slu_cur_file = 0;
	mutex_enter(&slu->slu_lock);
	slu->slu_flags |= SLUF_ALLOW_MEDIA_ACCESS;
	for (it = slu->slu_it_list; it != NULL;
	    it = it->stt_it_next) {
		it->stt_it_ua_conditions |= STT_UA_MEDIUM_LOADED;
	}
	mutex_exit(&slu->slu_lock);

load_media_meta_done:
	if (ret) {
		kmem_free(spi, sz);
	}
	return (ret);
}

int
stt_read_partition_info(uint8_t *guid, uint8_t *pi, uint32_t sz, int *err)
{
	stt_lu_t *slu = NULL;
	int ret;

	mutex_enter(&stt_global_lock);
	for (slu = stt_lu_list; slu; slu = slu->slu_next) {
		if (bcmp(slu->slu_device_id + 4, guid, 16) == 0) {
			mutex_enter(&slu->slu_lock);
			if (slu->slu_flags & SLUF_ALLOW_MEDIA_ACCESS) {
				sz = sz > slu->slu_spi->spi_alloc_size ?
				    slu->slu_spi->spi_alloc_size : sz;
				bcopy(slu->slu_spi, pi, sz);
				ret = 0;
				*err = 0;
			} else {
				ret = EIO;
				*err = STT_ERR_NO_MEDIA;
			}
			mutex_exit(&slu->slu_lock);
			mutex_exit(&stt_global_lock);
			return (ret);
		}
	}
	mutex_exit(&stt_global_lock);
	*err = STT_ERR_DRIVE_NOT_FOUND;
	return (ENOENT);
}

int
stt_read_drive_info(uint8_t *guid, stt_drive_info_t *di, int *err)
{
	stt_lu_t *slu = NULL;
	int ret;

	mutex_enter(&stt_global_lock);
	for (slu = stt_lu_list; slu; slu = slu->slu_next) {
		if (bcmp(slu->slu_device_id + 4, guid, 16) == 0) {
			mutex_enter(&slu->slu_lock);
			break;
		}
	}
	mutex_exit(&stt_global_lock);
	if (slu == NULL) {
		*err = STT_ERR_DRIVE_NOT_FOUND;
		return (ENOENT);
	}
	strncpy(di->meta_file_name, slu->slu_meta_file->f_name, 255);
	di->os_flags = slu->slu_flags;
	if (slu->slu_flags & SLUF_ALLOW_MEDIA_ACCESS) {
		strncpy(di->media_file_name, slu->slu_media_file->f_name, 255);
	}
	bcopy(slu->slu_device_id + 4, di->guid, 16);
	di->cur_blksize = slu->slu_cur_blksize;
	di->cur_slob_num = slu->slu_cur_file;
	di->cur_slob_off = slu->slu_cur_off;
	di->cur_stmf_state = slu->slu_state;
	di->cur_state_not_acked = slu->slu_state_not_acked;
	di->ntasks_needing_media = slu->slu_ntasks_needing_media;
	mutex_exit(&slu->slu_lock);
	*err = 0;
	return (0);
}
