/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License (the "License").
 * You may not use this file except in compliance with the License.
 *
 * You can obtain a copy of the license at usr/src/OPENSOLARIS.LICENSE
 * or http://www.opensolaris.org/os/licensing.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at usr/src/OPENSOLARIS.LICENSE.
 * If applicable, add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your own identifying
 * information: Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 */

/*
 * Copyright 2010 Nexenta Systems.  All rights reserved.
 * Use is subject to license terms.
 */

#include <sys/conf.h>
#include <sys/file.h>
#include <sys/ddi.h>
#include <sys/sunddi.h>
#include <sys/modctl.h>
#include <sys/scsi/scsi.h>
#include <sys/scsi/impl/scsi_reset_notify.h>
#include <sys/disp.h>
#include <sys/byteorder.h>
#include <sys/pathname.h>
#include <sys/atomic.h>
#include <sys/nvpair.h>
#include <sys/sdt.h>
#include <sys/dkio.h>

#include <sys/stmf.h>
#include <sys/lpif.h>
#include <sys/stmf_ioctl.h>
#include "stt.h"
#include "stt_file.h"
#include "stt_ioctl.h"

/*
 * Any locking (if needed) is done outside of this code.
 */

stt_file_t *
stt_file_open(char *name, int ro, int *err)
{
	stt_file_t *sf = NULL;
	vattr_t vattr;
	enum vtype vt;
	int ret;

	if (name[0] != '/') {
		*err = STT_ERR_PATH_NOT_ABSOLUTE;
		goto sfo_failed;
	}
	sf = kmem_zalloc(sizeof (*sf), KM_SLEEP);
	sf->f_name = kmem_zalloc(strlen (name) + 1, KM_SLEEP);
	strcpy(sf->f_name, name);
	if ((ret = lookupname(name, UIO_SYSSPACE, FOLLOW, NULLVPP,
	    &sf->f_vp)) != 0) {
		*err = STT_ERR_FILE_LOOKUP_FAILED;
		goto sfo_failed;
	}
	vt = sf->f_vp->v_type;
	VN_RELE(sf->f_vp);
	sf->f_vp = NULL;
	if (vt == VREG) {
		sf->f_flags |= STTF_VREG;
	} else if (vt == VCHR) {
		sf->f_flags |= STTF_VCHR;
	} else if (vt == VBLK) {
		sf->f_flags |= STTF_VBLK;
	} else {
		*err = STT_ERR_WRONG_FILE_TYPE;
		goto sfo_failed;
	}
	if (ro) {
		sf->f_flags |= STTF_READ_ONLY;
		sf->f_oflag = FREAD | FOFFMAX;
	} else {
		sf->f_oflag = FREAD | FWRITE | FOFFMAX | FEXCL;
	}
	if ((ret = vn_open(name, UIO_SYSSPACE, sf->f_oflag, 0,
	    &sf->f_vp, 0, 0)) != 0) {
		*err = STT_ERR_FILE_OPEN_FAILED;
		goto sfo_failed;
	}
	vattr.va_mask = AT_SIZE;
	if ((ret = VOP_GETATTR(sf->f_vp, &vattr, 0, CRED(), NULL)) != 0) {
		*err = STT_ERR_GETATTR_FAILED;
		goto sfo_failed;
	}
	sf->f_size = vattr.va_size;

	return (sf);

sfo_failed:
	stt_file_close(sf);
	return (NULL);
}

void
stt_file_close(stt_file_t *sf)
{
	if (!sf)
		return;

	if (sf->f_name) {
		kmem_free(sf->f_name, strlen(sf->f_name) + 1);
	}
	if (sf->f_vp) {
		(void) VOP_CLOSE(sf->f_vp, sf->f_oflag, 1, 0, CRED(), NULL);
		VN_RELE(sf->f_vp);
	}
	kmem_free(sf, sizeof (*sf));
}

/*
 * Check for read/write allow beyond EOF is done outside of these interfaces.
 */

int
stt_file_pread(stt_file_t *sf, uint8_t *buf, uint64_t off, uint64_t size,
    int *err)
{
	int ret;
	long resid;
	uint64_t store_end;

	if ((off + size) > sf->f_size) {
		if (off > sf->f_size) {
			bzero(buf, size);
			return (0);
		}
		store_end = sf->f_size - off;
		bzero(buf + store_end, size - store_end);
		size = store_end;
	}

	ret = vn_rdwr(UIO_READ, sf->f_vp, (caddr_t)buf, (ssize_t)size,
	    (offset_t)off, UIO_SYSSPACE, 0, RLIM64_INFINITY, CRED(),
	    &resid);

	if (ret || resid) {
		return (EIO);
	}

	return (0);
}

int
stt_file_pwrite(stt_file_t *sf, uint8_t *buf, uint64_t off, uint64_t sz,
    int *err)
{
	int ret, ioflag;
	long resid;

	if (sf->f_flags & STTF_SYNC_WRITE)
		ioflag = FSYNC;
	else
		ioflag = 0;

	ret = vn_rdwr(UIO_WRITE, sf->f_vp, (caddr_t)buf, (ssize_t)sz,
	    (offset_t)off, UIO_SYSSPACE, ioflag, RLIM64_INFINITY, CRED(),
	    &resid);

	if ((ioflag == FSYNC) && (ret == 0) && (resid == 0) &&
	    ((sf->f_flags & STTF_VREG) == 0)) {
		ret = stt_flush_write_cache(sf, 1);
	}

	if (ret || resid)
		return (EIO);

	if ((off + sz) > sf->f_size) {
		uint64_t os, ns;
		do {
			os = sf->f_size;
			if ((off + sz) <= os)
				break;
			ns = off + sz;
		} while (atomic_cas_64(&sf->f_size, os, ns) != os);
	}

	return (0);
}

int
stt_flush_write_cache(stt_file_t *sf, int fsync_done)
{
	int r = 0;
	int ret;

	if (fsync_done)
		goto over_fsync;
	if (sf->f_flags & (STTF_VBLK | STTF_VREG)) {
		if (VOP_FSYNC(sf->f_vp, FSYNC, kcred, NULL))
			return (EIO);
	}
over_fsync:
	if ((sf->f_flags & (STTF_VCHR | STTF_VBLK)) &&
	    ((sf->f_flags & STTF_DKIOFLUSH_NOT_SUPPORTED) == 0)) {
		ret = VOP_IOCTL(sf->f_vp, DKIOCFLUSHWRITECACHE, NULL,
		    FKIOCTL, kcred, &r, NULL);
		if ((ret == ENOTTY) || (ret == ENOTSUP)) {
			sf->f_flags |= STTF_DKIOFLUSH_NOT_SUPPORTED;
		} else if (ret != 0) {
			return (ret);
		}
	}

	return (0);
}
