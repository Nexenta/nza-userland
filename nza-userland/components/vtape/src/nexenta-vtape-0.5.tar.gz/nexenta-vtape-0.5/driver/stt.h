/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License (the "License").
 * You may not use this file except in compliance with the License.
 *
 * You can obtain a copy of the license at usr/src/OPENSOLARIS.LICENSE
 * or http://www.opensolaris.org/os/licensing.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at usr/src/OPENSOLARIS.LICENSE.
 * If applicable, add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your own identifying
 * information: Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 */

/*
 * Copyright 2010 Nexenta Systems.  All rights reserved.
 * Use is subject to license terms.
 */

#ifndef	_STT_H_
#define	_STT_H_

#ifdef	__cplusplus
extern "C" {
#endif

struct stt_file;
struct stt_partition_info;

#define	STT_MAGIC	0x5f53554d4954475f

typedef struct stt_meta_info {
	uint64_t	smi_magic;
	uint8_t		smi_major;
	uint8_t		smi_minor;
	uint16_t	smi_rsvd1;
	uint32_t	smi_flags;
	uint8_t		smi_guid[16];
	uint8_t		smi_media_file[256];
} stt_meta_info_t;

/*
 * meta info flags
 */
#define	SMIF_MEDIA_LOADED	0x0001
#define	SMIF_WRITE_PROTECTED	0x0002

typedef struct stt_it_data {
	struct stt_it_data	*stt_it_next;
	uint64_t		stt_it_session_id;
	uint8_t			stt_it_lun[8];
	uint8_t			stt_it_ua_conditions;
	uint8_t			stt_it_flags;
} stt_it_data_t;
/*
 * it_flags
 */
#define	STT_IT_HAS_SCSI2_RESERVATION	0x0001

typedef struct stt_lu {
	struct stt_lu		*slu_next;
	stmf_lu_t		*slu_lu;

	kmutex_t		slu_lock;
	uint32_t		slu_flags;
	uint8_t			slu_state:7,
				slu_state_not_acked:1;
	struct stt_file		*slu_meta_file;
	struct stt_file		*slu_media_file;
	stt_it_data_t		*slu_it_list;
	uint8_t			slu_device_id[20];
	uint32_t		slu_ntasks_needing_media;
	uint32_t		slu_cur_blksize;
	uint32_t		slu_cur_file;
	uint64_t		slu_cur_off;
	struct stt_partition_info *slu_spi;
} stt_lu_t;

/*
 * LU flags
 */
#define	SLUF_LU_BUSY				0x0001
#define	SLUF_WRITE_PROTECTED			0x0002
#define	SLUF_MEDIUM_REMOVAL_PREVENTED		0x0004
#define	SLUF_LU_HAS_SCSI2_RESERVATION		0x0008
#define	SLUF_ALLOW_MEDIA_ACCESS			0x0010
#define	SLUF_MEDIA_META_DIRTY			0x0020

typedef struct stt_cmd {
	uint8_t		flags;
	uint8_t		nbufs;
	uint16_t	cmd_type;	/* Type of command */
	uint32_t	rsvd2;
	uint64_t	addr;		/* current */
	uint32_t	len;		/* len left */
	uint32_t	current_ro;	/* running relative offset */
} stt_cmd_t;

/*
 * flags for sbd_cmd
 */
#define	STT_SCSI_CMD_ACTIVE		0x01
#define	STT_SCSI_CMD_ABORT_REQUESTED	0x02
#define	STT_SCSI_CMD_XFER_FAIL		0x04

/*
 * cmd types
 */
#define	STT_CMD_SCSI_READ	0x01
#define	STT_CMD_SCSI_WRITE	0x02
#define	STT_CMD_SMALL_READ	0x03
#define	STT_CMD_SMALL_WRITE	0x04

/*
 * Different UA conditions
 */
#define	STT_UA_POR				0x01
#define	STT_UA_MODE_PARAMETERS_CHANGED		0x02
#define	STT_UA_MEDIUM_LOADED			0x04

void stt_ctl(struct stmf_lu *lu, int cmd, void *arg);
stmf_status_t stt_task_alloc(struct scsi_task *task);
void stt_remove_it_handle(stt_lu_t *slu, stt_it_data_t *it);
void stt_check_and_clear_scsi2_reservation(stt_lu_t *slu, stt_it_data_t *it);
void stt_new_task(struct scsi_task *task, struct stmf_data_buf *initial_dbuf);
void stt_dbuf_xfer_done(struct scsi_task *task, struct stmf_data_buf *dbuf);
void stt_send_status_done(struct scsi_task *task);
void stt_task_free(struct scsi_task *task);
stmf_status_t stt_abort(struct stmf_lu *lu, int abort_cmd, void *arg,
    uint32_t flags);
stmf_status_t stt_info(uint32_t cmd, stmf_lu_t *lu, void *arg, uint8_t *buf,
    uint32_t *bufsizep);

#ifdef	__cplusplus
}
#endif

#endif /* _STT_H_ */
