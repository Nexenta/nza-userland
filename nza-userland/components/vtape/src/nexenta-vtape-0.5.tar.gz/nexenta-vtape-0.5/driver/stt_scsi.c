/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License (the "License").
 * You may not use this file except in compliance with the License.
 *
 * You can obtain a copy of the license at usr/src/OPENSOLARIS.LICENSE
 * or http://www.opensolaris.org/os/licensing.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at usr/src/OPENSOLARIS.LICENSE.
 * If applicable, add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your own identifying
 * information: Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 */

/*
 * Copyright 2010 Nexenta Systems.  All rights reserved.
 * Use is subject to license terms.
 */

#include <sys/conf.h>
#include <sys/file.h>
#include <sys/ddi.h>
#include <sys/sunddi.h>
#include <sys/modctl.h>
#include <sys/scsi/scsi.h>
#include <sys/scsi/impl/scsi_reset_notify.h>
#include <sys/disp.h>
#include <sys/byteorder.h>
#include <sys/pathname.h>
#include <sys/atomic.h>
#include <sys/nvpair.h>
#include <sys/fs/zfs.h>
#include <sys/sdt.h>
#include <sys/dkio.h>

#include <sys/stmf.h>
#include <sys/lpif.h>
#include <sys/portif.h>
#include <sys/stmf_ioctl.h>
#include "stt.h"
#include "stt_file.h"
#include "stt_ioctl.h"

#define	SENSEF_INFO_VALID		0x01
#define	SENSEF_FILEMARK			0x80
#define	SENSEF_EOM			0x40
#define	SENSEF_ILI			0x20

#define	STMF_SAA_OVERFLOW_EOP		0x0D0002
#define	STMF_SAA_FILEMARK_DETECTED	0x000001
#define	STMF_SAA_SENSE_EOP_DETECTED	0x030002
#define	STMF_SAA_NO_SENSE_EOP_DETECTED	0x000002
#define	STMF_SAA_EOD_DETECTED		0x080005
#define	STMF_SAA_BOP_DETECTED		0x000004
#define	STMF_SAA_MEDIUM_LOADED		0x062800

extern char stt_vid[];

/*
 * Steal a bit in the task additional flags to indicate if we need
 * to update our ref counts for this task.
 */
#define	TASK_AF_NEED_REF_REMOVAL	0x8000
#define	STT_REMOVE_REF(slu, task)					\
    {									\
	if (task->task_additional_flags & TASK_AF_NEED_REF_REMOVAL) {	\
		atomic_add_32(&slu->slu_ntasks_needing_media, -1);	\
		task->task_additional_flags &=				\
		    ~TASK_AF_NEED_REF_REMOVAL;				\
	}								\
    }

void stt_handle_short_write_xfer_completion(scsi_task_t *task,
    stmf_data_buf_t *dbuf);
void stt_handle_short_write_transfers(scsi_task_t *task,
    stmf_data_buf_t *dbuf, uint32_t cdb_xfer_size);
void stt_handle_short_read_xfer_completion(struct scsi_task *task,
    stt_cmd_t *scmd, struct stmf_data_buf *dbuf);
void stt_handle_short_read_transfers(scsi_task_t *task,
    stmf_data_buf_t *dbuf, uint8_t *p, uint32_t cdb_xfer_size,
    uint32_t cmd_xfer_size);
void stt_handle_mode_select_xfer(scsi_task_t *task, uint8_t *buf,
    uint32_t buflen);
stmf_status_t stt_lu_reset_state(stmf_lu_t *lu);
void stt_handle_read_blklim(struct scsi_task *task,
    struct stmf_data_buf *initial_dbuf);
void stt_handle_write_filemarks(struct scsi_task *task);
void stt_handle_space(struct scsi_task *task);
void stt_handle_mode_sense(scsi_task_t *task,
    stmf_data_buf_t *initial_dbuf, uint8_t *buf);
void stt_handle_mode_select(scsi_task_t *task, stmf_data_buf_t *dbuf);
void stt_handle_read_xfer_completion(struct scsi_task *task, stt_cmd_t *scmd,
    struct stmf_data_buf *dbuf);
void stt_handle_read(struct scsi_task *task,
    struct stmf_data_buf *initial_dbuf);
int stt_check_media(stt_lu_t *slu, struct scsi_task *task,
    int bump_ref, int excl);
void stt_send_status(scsi_task_t *task, uint8_t st, uint8_t sensef,
    uint32_t saa, uint32_t info);
void stt_handle_doorlock(scsi_task_t *task);

#define	SCSI2_CONFLICT_FREE_CMDS(cdb)	( \
	/* ----------------------- */                                      \
	/* Refer Both		   */                                      \
	/* SPC-2 (rev 20) Table 10 */                                      \
	/* SPC-3 (rev 23) Table 31 */                                      \
	/* ----------------------- */                                      \
	((cdb[0]) == SCMD_INQUIRY)					|| \
	((cdb[0]) == SCMD_LOG_SENSE_G1)					|| \
	((cdb[0]) == SCMD_RELEASE)					|| \
	((cdb[0]) == SCMD_RELEASE_G1)					|| \
	((cdb[0]) == SCMD_REPORT_LUNS)					|| \
	((cdb[0]) == SCMD_REQUEST_SENSE)				|| \
	/* PREVENT ALLOW MEDIUM REMOVAL with prevent == 0 */               \
	((((cdb[0]) == SCMD_DOORLOCK) && (((cdb[4]) & 0x3) == 0)))	|| \
	/* SERVICE ACTION IN with READ MEDIA SERIAL NUMBER (0x01) */       \
	(((cdb[0]) == SCMD_SVC_ACTION_IN_G5) && (                          \
	    ((cdb[1]) & 0x1F) == 0x01))					|| \
	/* MAINTENANCE IN with service actions REPORT ALIASES (0x0Bh) */   \
	/* REPORT DEVICE IDENTIFIER (0x05)  REPORT PRIORITY (0x0Eh) */     \
	/* REPORT TARGET PORT GROUPS (0x0A) REPORT TIMESTAMP (0x0F) */     \
	(((cdb[0]) == SCMD_MAINTENANCE_IN) && (                            \
	    (((cdb[1]) & 0x1F) == 0x0B) ||                                 \
	    (((cdb[1]) & 0x1F) == 0x05) ||                                 \
	    (((cdb[1]) & 0x1F) == 0x0E) ||                                 \
	    (((cdb[1]) & 0x1F) == 0x0A) ||                                 \
	    (((cdb[1]) & 0x1F) == 0x0F)))				|| \
	/* ----------------------- */                                      \
	/* SBC-3 (rev 17) Table 3  */                                      \
	/* ----------------------- */                                      \
	/* READ CAPACITY(10) */                                            \
	((cdb[0]) == SCMD_READ_CAPACITY)				|| \
	/* READ CAPACITY(16) */                                            \
	(((cdb[0]) == SCMD_SVC_ACTION_IN_G4) && (                          \
	    ((cdb[1]) & 0x1F) == 0x10))					|| \
	/* START STOP UNIT with START bit 0 and POWER CONDITION 0  */      \
	(((cdb[0]) == SCMD_START_STOP) && (                                \
	    (((cdb[4]) & 0xF0) == 0) && (((cdb[4]) & 0x01) == 0))))
/* End of SCSI2_CONFLICT_FREE_CMDS */

void
stt_do_read_xfer(struct scsi_task *task, stt_cmd_t *scmd,
					struct stmf_data_buf *dbuf)
{
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	uint64_t laddr;
	uint32_t len, buflen, iolen;
	int ndx, err;
	int bufs_to_take;

	/* Lets try not to hog all the buffers the port has. */
	bufs_to_take = ((task->task_max_nbufs > 2) &&
	    (task->task_cmd_xfer_length < (32 * 1024))) ? 2 :
	    task->task_max_nbufs;

	len = scmd->len > dbuf->db_buf_size ? dbuf->db_buf_size : scmd->len;
	laddr = scmd->addr + scmd->current_ro;

	for (buflen = 0, ndx = 0; (buflen < len) &&
	    (ndx < dbuf->db_sglist_length); ndx++) {
		iolen = min(len - buflen, dbuf->db_sglist[ndx].seg_length);
		if (iolen == 0)
			break;
		if (stt_file_pread(slu->slu_media_file,
		    dbuf->db_sglist[ndx].seg_addr, laddr, (uint64_t)iolen,
		    &err) != 0) {
			scmd->flags |= STT_SCSI_CMD_XFER_FAIL;
			/* Do not need to do xfer anymore, just complete it */
			dbuf->db_data_size = 0;
			dbuf->db_xfer_status = STMF_SUCCESS;
			stt_handle_read_xfer_completion(task, scmd, dbuf);
			return;
		}
		buflen += iolen;
		laddr += (uint64_t)iolen;
	}
	dbuf->db_relative_offset = scmd->current_ro;
	dbuf->db_data_size = buflen;
	dbuf->db_flags = DB_DIRECTION_TO_RPORT;
	(void) stmf_xfer_data(task, dbuf, 0);
	scmd->len -= buflen;
	scmd->current_ro += buflen;
	if (scmd->len && (scmd->nbufs < bufs_to_take)) {
		uint32_t maxsize, minsize, old_minsize;

		maxsize = (scmd->len > (128*1024)) ? 128*1024 : scmd->len;
		minsize = maxsize >> 2;
		do {
			/*
			 * A bad port implementation can keep on failing the
			 * the request but keep on sending us a false
			 * minsize.
			 */
			old_minsize = minsize;
			dbuf = stmf_alloc_dbuf(task, maxsize, &minsize, 0);
		} while ((dbuf == NULL) && (old_minsize > minsize) &&
		    (minsize >= 512));
		if (dbuf == NULL) {
			return;
		}
		scmd->nbufs++;
		stt_do_read_xfer(task, scmd, dbuf);
	}
}

void
stt_handle_read_xfer_completion(struct scsi_task *task, stt_cmd_t *scmd,
				struct stmf_data_buf *dbuf)
{
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;

	if (dbuf->db_xfer_status != STMF_SUCCESS) {
		stmf_abort(STMF_QUEUE_TASK_ABORT, task,
		    dbuf->db_xfer_status, NULL);
		return;
	}
	task->task_nbytes_transferred += dbuf->db_data_size;
	if (scmd->len == 0 || scmd->flags & STT_SCSI_CMD_XFER_FAIL) {
		stmf_free_dbuf(task, dbuf);
		scmd->nbufs--;
		if (scmd->nbufs)
			return;	/* wait for all buffers to complete */
		scmd->flags &= ~STT_SCSI_CMD_ACTIVE;
		STT_REMOVE_REF(slu, task);
		if (scmd->flags & STT_SCSI_CMD_XFER_FAIL)
			stmf_scsilib_send_status(task, STATUS_CHECK,
			    STMF_SAA_READ_ERROR);
		else {
			slu->slu_cur_off += scmd->current_ro;
			stmf_scsilib_send_status(task, STATUS_GOOD, 0);
		}
		return;
	}
	if (dbuf->db_flags & DB_DONT_REUSE) {
		/* allocate new dbuf */
		uint32_t maxsize, minsize, old_minsize;
		stmf_free_dbuf(task, dbuf);

		maxsize = (scmd->len > (128*1024)) ? 128*1024 : scmd->len;
		minsize = maxsize >> 2;
		do {
			old_minsize = minsize;
			dbuf = stmf_alloc_dbuf(task, maxsize, &minsize, 0);
		} while ((dbuf == NULL) && (old_minsize > minsize) &&
		    (minsize >= 512));
		if (dbuf == NULL) {
			scmd->nbufs --;
			if (scmd->nbufs == 0) {
				stmf_abort(STMF_QUEUE_TASK_ABORT, task,
				    STMF_ALLOC_FAILURE, NULL);
			}
			return;
		}
	}
	stt_do_read_xfer(task, scmd, dbuf);
}

void
stt_handle_read(struct scsi_task *task, struct stmf_data_buf *initial_dbuf)
{
	stt_lobj_t *slob;
	uint64_t laddr;
	uint32_t len;
	uint8_t op = task->task_cdb[0];
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	stt_cmd_t *scmd;
	stmf_data_buf_t *dbuf;
	int fast_path;

	len = task->task_cdb[2];
	len <<= 8;
	len |= task->task_cdb[3];
	len <<= 8;
	len |= task->task_cdb[4];
	len *= slu->slu_cur_blksize;

	slob = &slu->slu_spi->spi_slobs[slu->slu_cur_file];
	if (len > (slob->slob_valid_data_size - slu->slu_cur_off)) {
		mutex_enter(&slu->slu_lock);
		len -= slob->slob_valid_data_size - slu->slu_cur_off;
		if (slob->slob_valid_data_size < slob->slob_max_size) {
			slu->slu_cur_off = slob->slob_valid_data_size;
			mutex_exit(&slu->slu_lock);
			stt_send_status(task, STATUS_CHECK,
			    SENSEF_INFO_VALID, STMF_SAA_EOD_DETECTED,
			    (uint32_t)(len / slu->slu_cur_blksize));
			return;
		}
		if (slu->slu_cur_file < (slu->slu_spi->spi_num_slobs - 1)) {
			slu->slu_cur_file++;
			slu->slu_cur_off = 0;
			slob = &slu->slu_spi->spi_slobs[slu->slu_cur_file];
			mutex_exit(&slu->slu_lock);
			if (slob->slob_max_size == 0) {
				stt_send_status(task, STATUS_CHECK,
				    SENSEF_EOM | SENSEF_INFO_VALID,
				    STMF_SAA_SENSE_EOP_DETECTED,
				    (uint32_t)(len / slu->slu_cur_blksize));
			} else {
				stt_send_status(task, STATUS_CHECK,
				    SENSEF_INFO_VALID | SENSEF_FILEMARK,
				    STMF_SAA_FILEMARK_DETECTED,
				    (uint32_t)(len / slu->slu_cur_blksize));
			}
			return;
		}
		slu->slu_cur_off = slob->slob_valid_data_size;
		mutex_exit(&slu->slu_lock);
		stt_send_status(task, STATUS_CHECK,
		    SENSEF_INFO_VALID | SENSEF_FILEMARK,
		    STMF_SAA_FILEMARK_DETECTED,
		    (uint32_t)(len / slu->slu_cur_blksize));
		return;
	}
	laddr = slob->slob_start_addr + slu->slu_cur_off;
	task->task_cmd_xfer_length = len;
	if (task->task_additional_flags & TASK_AF_NO_EXPECTED_XFER_LENGTH) {
		task->task_expected_xfer_length = len;
	}

	if (len != task->task_expected_xfer_length) {
		fast_path = 0;
		len = (len > task->task_expected_xfer_length) ?
		    task->task_expected_xfer_length : len;
	} else {
		fast_path = 1;
	}

	if (len == 0) {
		STT_REMOVE_REF(slu, task);
		stmf_scsilib_send_status(task, STATUS_GOOD, 0);
		return;
	}

	if (initial_dbuf == NULL) {
		uint32_t maxsize, minsize, old_minsize;

		maxsize = (len > (128*1024)) ? 128*1024 : len;
		minsize = maxsize >> 2;
		do {
			old_minsize = minsize;
			initial_dbuf = stmf_alloc_dbuf(task, maxsize,
			    &minsize, 0);
		} while ((initial_dbuf == NULL) && (old_minsize > minsize) &&
		    (minsize >= 512));
		if (initial_dbuf == NULL) {
			STT_REMOVE_REF(slu, task);
			stmf_scsilib_send_status(task, STATUS_QFULL, 0);
			return;
		}
	}
	dbuf = initial_dbuf;

	if ((dbuf->db_buf_size >= len) && fast_path &&
	    (dbuf->db_sglist_length == 1)) {
		int err;

		if (stt_file_pread(slu->slu_media_file,
		    dbuf->db_sglist[0].seg_addr, laddr, (uint64_t)len,
		    &err) == 0) {
			dbuf->db_relative_offset = 0;
			dbuf->db_data_size = len;
			dbuf->db_flags = DB_SEND_STATUS_GOOD |
			    DB_DIRECTION_TO_RPORT;
			STT_REMOVE_REF(slu, task);
			(void) stmf_xfer_data(task, dbuf, STMF_IOF_LU_DONE);
			slu->slu_cur_off += len;
		} else {
			STT_REMOVE_REF(slu, task);
			stmf_scsilib_send_status(task, STATUS_CHECK,
			    STMF_SAA_READ_ERROR);
		}
		return;
	}

	if (task->task_lu_private) {
		scmd = (stt_cmd_t *)task->task_lu_private;
	} else {
		scmd = (stt_cmd_t *)kmem_alloc(sizeof (stt_cmd_t), KM_SLEEP);
		task->task_lu_private = scmd;
	}
	scmd->flags = STT_SCSI_CMD_ACTIVE;
	scmd->cmd_type = STT_CMD_SCSI_READ;
	scmd->nbufs = 1;
	scmd->addr = laddr;
	scmd->len = len;
	scmd->current_ro = 0;

	stt_do_read_xfer(task, scmd, dbuf);
}

void
stt_do_write_xfer(struct scsi_task *task, stt_cmd_t *scmd,
					struct stmf_data_buf *dbuf)
{
	uint32_t len;
	int bufs_to_take;

	/* Lets try not to hog all the buffers the port has. */
	bufs_to_take = ((task->task_max_nbufs > 2) &&
	    (task->task_cmd_xfer_length < (32 * 1024))) ? 2 :
	    task->task_max_nbufs;

	len = scmd->len > dbuf->db_buf_size ? dbuf->db_buf_size : scmd->len;

	dbuf->db_relative_offset = scmd->current_ro;
	dbuf->db_data_size = len;
	dbuf->db_flags = DB_DIRECTION_FROM_RPORT;
	(void) stmf_xfer_data(task, dbuf, 0);
	scmd->len -= len;
	scmd->current_ro += len;
	if (scmd->len && (scmd->nbufs < bufs_to_take)) {
		uint32_t maxsize, minsize, old_minsize;

		maxsize = (scmd->len > (128*1024)) ? 128*1024 : scmd->len;
		minsize = maxsize >> 2;
		do {
			old_minsize = minsize;
			dbuf = stmf_alloc_dbuf(task, maxsize, &minsize, 0);
		} while ((dbuf == NULL) && (old_minsize > minsize) &&
		    (minsize >= 512));
		if (dbuf == NULL) {
			return;
		}
		scmd->nbufs++;
		stt_do_write_xfer(task, scmd, dbuf);
	}
}

void
stt_handle_write_xfer_completion(struct scsi_task *task, stt_cmd_t *scmd,
    struct stmf_data_buf *dbuf, uint8_t dbuf_reusable)
{
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	uint64_t laddr;
	uint32_t buflen, iolen;
	int ndx, err;

	if (dbuf->db_xfer_status != STMF_SUCCESS) {
		stmf_abort(STMF_QUEUE_TASK_ABORT, task,
		    dbuf->db_xfer_status, NULL);
		return;
	}

	if (scmd->flags & STT_SCSI_CMD_XFER_FAIL) {
		goto WRITE_XFER_DONE;
	}

	laddr = scmd->addr + dbuf->db_relative_offset;

	for (buflen = 0, ndx = 0; (buflen < dbuf->db_data_size) &&
	    (ndx < dbuf->db_sglist_length); ndx++) {
		iolen = min(dbuf->db_data_size - buflen,
		    dbuf->db_sglist[ndx].seg_length);
		if (iolen == 0)
			break;
		if (stt_file_pwrite(slu->slu_media_file,
		    dbuf->db_sglist[ndx].seg_addr, laddr, (uint64_t)iolen,
		    &err) != 0) {
			scmd->flags |= STT_SCSI_CMD_XFER_FAIL;
			break;
		}
		buflen += iolen;
		laddr += (uint64_t)iolen;
	}
	task->task_nbytes_transferred += buflen;
WRITE_XFER_DONE:
	if (scmd->len == 0 || scmd->flags & STT_SCSI_CMD_XFER_FAIL) {
		stmf_free_dbuf(task, dbuf);
		scmd->nbufs--;
		if (scmd->nbufs)
			return;	/* wait for all buffers to complete */
		scmd->flags &= ~STT_SCSI_CMD_ACTIVE;
		STT_REMOVE_REF(slu, task);
		if (scmd->flags & STT_SCSI_CMD_XFER_FAIL) {
			stmf_scsilib_send_status(task, STATUS_CHECK,
			    STMF_SAA_WRITE_ERROR);
		} else {
			stt_lobj_t *slob;

			mutex_enter(&slu->slu_lock);
			slu->slu_cur_off += scmd->current_ro;
			slob = &slu->slu_spi->spi_slobs[slu->slu_cur_file];
			slob->slob_valid_data_size += scmd->current_ro;
			slu->slu_flags |= SLUF_MEDIA_META_DIRTY;
			mutex_exit(&slu->slu_lock);
			stmf_scsilib_send_status(task, STATUS_GOOD, 0);
		}
		return;
	}
	if (dbuf->db_flags & DB_DONT_REUSE || dbuf_reusable == 0) {
		uint32_t maxsize, minsize, old_minsize;
		/* free current dbuf and allocate a new one */
		stmf_free_dbuf(task, dbuf);

		maxsize = (scmd->len > (128*1024)) ? 128*1024 : scmd->len;
		minsize = maxsize >> 2;
		do {
			old_minsize = minsize;
			dbuf = stmf_alloc_dbuf(task, maxsize, &minsize, 0);
		} while ((dbuf == NULL) && (old_minsize > minsize) &&
		    (minsize >= 512));
		if (dbuf == NULL) {
			scmd->nbufs --;
			if (scmd->nbufs == 0) {
				stmf_abort(STMF_QUEUE_TASK_ABORT, task,
				    STMF_ALLOC_FAILURE, NULL);
			}
			return;
		}
	}
	stt_do_write_xfer(task, scmd, dbuf);
}

void
stt_handle_write(struct scsi_task *task, struct stmf_data_buf *initial_dbuf)
{
	stt_lobj_t *slob;
	uint64_t laddr;
	uint32_t len;
	uint8_t op = task->task_cdb[0], do_immediate_data = 0;
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	stt_cmd_t *scmd;
	stmf_data_buf_t *dbuf;
	int i;

	if (slu->slu_flags & SLUF_WRITE_PROTECTED) {
		STT_REMOVE_REF(slu, task);
		stmf_scsilib_send_status(task, STATUS_CHECK,
		    STMF_SAA_WRITE_PROTECTED);
		return;
	}
	if (!(task->task_cdb[1] & 1)) {
		STT_REMOVE_REF(slu, task);
		stmf_scsilib_send_status(task, STATUS_CHECK,
		    STMF_SAA_INVALID_FIELD_IN_CDB);
		return;
	}
	len = task->task_cdb[2];
	len <<= 8;
	len |= task->task_cdb[3];
	len <<= 8;
	len |= task->task_cdb[4];
	len *= slu->slu_cur_blksize;

	slob = &slu->slu_spi->spi_slobs[slu->slu_cur_file];

	ASSERT(slu->slu_cur_off <= slob->slob_valid_data_size);
	if (slu->slu_cur_file != (slu->slu_spi->spi_num_slobs - 1)) {
		mutex_enter(&slu->slu_lock);
		slob->slob_max_size = slu->slu_media_file->f_size -
		    slob->slob_start_addr;
		slu->slu_spi->spi_num_slobs = slu->slu_cur_file + 1;
		slu->slu_flags |= SLUF_MEDIA_META_DIRTY;
		mutex_exit(&slu->slu_lock);
	}

	if ((slu->slu_cur_off + len) > slob->slob_max_size) {
		stt_send_status(task, STATUS_CHECK, SENSEF_INFO_VALID |
		    SENSEF_EOM, STMF_SAA_OVERFLOW_EOP,
		    (uint32_t)(len / slu->slu_cur_blksize));
		return;
	}
	laddr = slob->slob_start_addr + slu->slu_cur_off;
	task->task_cmd_xfer_length = len;

	if (task->task_additional_flags & TASK_AF_NO_EXPECTED_XFER_LENGTH) {
		task->task_expected_xfer_length = len;
	}

	len = (len > task->task_expected_xfer_length) ?
	    task->task_expected_xfer_length : len;

	if (len == 0) {
		STT_REMOVE_REF(slu, task);
		stmf_scsilib_send_status(task, STATUS_GOOD, 0);
		return;
	}

	if (initial_dbuf == NULL) {
		uint32_t maxsize, minsize, old_minsize;

		maxsize = (len > (128*1024)) ? 128*1024 : len;
		minsize = maxsize >> 2;
		do {
			old_minsize = minsize;
			initial_dbuf = stmf_alloc_dbuf(task, maxsize,
			    &minsize, 0);
		} while ((initial_dbuf == NULL) && (old_minsize > minsize) &&
		    (minsize >= 512));
		if (initial_dbuf == NULL) {
			stmf_abort(STMF_QUEUE_TASK_ABORT, task,
			    STMF_ALLOC_FAILURE, NULL);
			return;
		}
	} else if (task->task_flags & TF_INITIAL_BURST) {
		if (initial_dbuf->db_data_size > len) {
			if (initial_dbuf->db_data_size >
			    task->task_expected_xfer_length) {
				/* protocol error */
				stmf_abort(STMF_QUEUE_TASK_ABORT, task,
				    STMF_INVALID_ARG, NULL);
				return;
			}
			initial_dbuf->db_data_size = len;
		}
		do_immediate_data = 1;
	}
	dbuf = initial_dbuf;

	if (task->task_lu_private) {
		scmd = (stt_cmd_t *)task->task_lu_private;
	} else {
		scmd = (stt_cmd_t *)kmem_alloc(sizeof (stt_cmd_t), KM_SLEEP);
		task->task_lu_private = scmd;
	}
	scmd->flags = STT_SCSI_CMD_ACTIVE;
	scmd->cmd_type = STT_CMD_SCSI_WRITE;
	scmd->nbufs = 1;
	scmd->addr = laddr;
	scmd->len = len;
	scmd->current_ro = 0;

	if (do_immediate_data) {
		scmd->len -= dbuf->db_data_size;
		scmd->current_ro += dbuf->db_data_size;
		dbuf->db_xfer_status = STMF_SUCCESS;
		stt_handle_write_xfer_completion(task, scmd, dbuf, 0);
	} else {
		stt_do_write_xfer(task, scmd, dbuf);
	}
}

/*
 * Utility routine to handle small non performance data transfers to the
 * initiators. dbuf is an initial data buf (if any), 'p' points to a data
 * buffer which is source of data for transfer, cdb_xfer_size is the
 * transfer size based on CDB, cmd_xfer_size is the actual amount of data
 * which this command would transfer (the size of data pointed to by 'p').
 */
void
stt_handle_short_read_transfers(scsi_task_t *task, stmf_data_buf_t *dbuf,
    uint8_t *p, uint32_t cdb_xfer_size, uint32_t cmd_xfer_size)
{
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	uint32_t bufsize, ndx;
	stt_cmd_t *scmd;

	cmd_xfer_size = min(cmd_xfer_size, cdb_xfer_size);

	task->task_cmd_xfer_length = cmd_xfer_size;
	if (task->task_additional_flags & TASK_AF_NO_EXPECTED_XFER_LENGTH) {
		task->task_expected_xfer_length = cmd_xfer_size;
	} else {
		cmd_xfer_size = min(cmd_xfer_size,
		    task->task_expected_xfer_length);
	}

	if (cmd_xfer_size == 0) {
		STT_REMOVE_REF(slu, task);
		stmf_scsilib_send_status(task, STATUS_CHECK,
		    STMF_SAA_INVALID_FIELD_IN_CDB);
		return;
	}
	if (dbuf == NULL) {
		uint32_t minsize = cmd_xfer_size;

		dbuf = stmf_alloc_dbuf(task, cmd_xfer_size, &minsize, 0);
	}
	if (dbuf == NULL) {
		STT_REMOVE_REF(slu, task);
		stmf_scsilib_send_status(task, STATUS_QFULL, 0);
		return;
	}

	for (bufsize = 0, ndx = 0; bufsize < cmd_xfer_size; ndx++) {
		uint8_t *d;
		uint32_t s;

		d = dbuf->db_sglist[ndx].seg_addr;
		s = min((cmd_xfer_size - bufsize),
		    dbuf->db_sglist[ndx].seg_length);
		bcopy(p+bufsize, d, s);
		bufsize += s;
	}
	dbuf->db_relative_offset = 0;
	dbuf->db_data_size = cmd_xfer_size;
	dbuf->db_flags = DB_DIRECTION_TO_RPORT;

	if (task->task_lu_private == NULL) {
		task->task_lu_private =
		    kmem_alloc(sizeof (stt_cmd_t), KM_SLEEP);
	}
	scmd = (stt_cmd_t *)task->task_lu_private;

	scmd->cmd_type = STT_CMD_SMALL_READ;
	scmd->flags = STT_SCSI_CMD_ACTIVE;
	(void) stmf_xfer_data(task, dbuf, 0);
}

void
stt_handle_short_read_xfer_completion(struct scsi_task *task, stt_cmd_t *scmd,
				struct stmf_data_buf *dbuf)
{
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	if (dbuf->db_xfer_status != STMF_SUCCESS) {
		stmf_abort(STMF_QUEUE_TASK_ABORT, task,
		    dbuf->db_xfer_status, NULL);
		return;
	}
	task->task_nbytes_transferred = dbuf->db_data_size;
	scmd->flags &= ~STT_SCSI_CMD_ACTIVE;
	STT_REMOVE_REF(slu, task);
	stmf_scsilib_send_status(task, STATUS_GOOD, 0);
}

void
stt_handle_short_write_transfers(scsi_task_t *task,
    stmf_data_buf_t *dbuf, uint32_t cdb_xfer_size)
{
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	stt_cmd_t *scmd;

	task->task_cmd_xfer_length = cdb_xfer_size;
	if (task->task_additional_flags & TASK_AF_NO_EXPECTED_XFER_LENGTH) {
		task->task_expected_xfer_length = cdb_xfer_size;
	} else {
		cdb_xfer_size = min(cdb_xfer_size,
		    task->task_expected_xfer_length);
	}

	if (cdb_xfer_size == 0) {
		STT_REMOVE_REF(slu, task);
		stmf_scsilib_send_status(task, STATUS_CHECK,
		    STMF_SAA_INVALID_FIELD_IN_CDB);
		return;
	}
	if (task->task_lu_private == NULL) {
		task->task_lu_private = kmem_zalloc(sizeof (stt_cmd_t),
		    KM_SLEEP);
	} else {
		bzero(task->task_lu_private, sizeof (stt_cmd_t));
	}
	scmd = (stt_cmd_t *)task->task_lu_private;
	scmd->cmd_type = STT_CMD_SMALL_WRITE;
	scmd->flags = STT_SCSI_CMD_ACTIVE;
	scmd->len = cdb_xfer_size;
	if (dbuf == NULL) {
		uint32_t minsize = cdb_xfer_size;

		dbuf = stmf_alloc_dbuf(task, cdb_xfer_size, &minsize, 0);
		if (dbuf == NULL) {
			stmf_abort(STMF_QUEUE_TASK_ABORT, task,
			    STMF_ALLOC_FAILURE, NULL);
			return;
		}
		dbuf->db_data_size = cdb_xfer_size;
		dbuf->db_relative_offset = 0;
		dbuf->db_flags = DB_DIRECTION_FROM_RPORT;
		stmf_xfer_data(task, dbuf, 0);
	} else {
		if (dbuf->db_data_size < cdb_xfer_size) {
			stmf_abort(STMF_QUEUE_TASK_ABORT, task,
			    STMF_ABORTED, NULL);
			return;
		}
		dbuf->db_data_size = cdb_xfer_size;
		stt_handle_short_write_xfer_completion(task, dbuf);
	}
}

void
stt_handle_short_write_xfer_completion(scsi_task_t *task,
    stmf_data_buf_t *dbuf)
{
	stt_cmd_t *scmd;
	stmf_status_t st_ret;
	stt_lu_t *sl = (stt_lu_t *)task->task_lu->lu_provider_private;

	/*
	 * For now lets assume we will get only one sglist element
	 * for short writes. If that ever changes, we should allocate
	 * a local buffer and copy all the sg elements to one linear space.
	 */
	if ((dbuf->db_xfer_status != STMF_SUCCESS) ||
	    (dbuf->db_sglist_length > 1)) {
		stmf_abort(STMF_QUEUE_TASK_ABORT, task,
		    dbuf->db_xfer_status, NULL);
		return;
	}

	task->task_nbytes_transferred = dbuf->db_data_size;
	scmd = (stt_cmd_t *)task->task_lu_private;
	scmd->flags &= ~STT_SCSI_CMD_ACTIVE;

	/* Lets find out who to call */
	switch (task->task_cdb[0]) {
	case SCMD_MODE_SELECT:
		stt_handle_mode_select_xfer(task,
		    dbuf->db_sglist[0].seg_addr, dbuf->db_data_size);
		break;
	default:
		/* This should never happen */
		stmf_abort(STMF_QUEUE_TASK_ABORT, task,
		    STMF_ABORTED, NULL);
	}
}

void
stt_ctl(struct stmf_lu *lu, int cmd, void *arg)
{
	stt_lu_t *slu = (stt_lu_t *)lu->lu_provider_private;
	stmf_change_status_t st;

	ASSERT((cmd == STMF_CMD_LU_ONLINE) ||
	    (cmd == STMF_CMD_LU_OFFLINE) ||
	    (cmd == STMF_ACK_LU_ONLINE_COMPLETE) ||
	    (cmd == STMF_ACK_LU_OFFLINE_COMPLETE));

	st.st_completion_status = STMF_SUCCESS;
	st.st_additional_info = NULL;

	switch (cmd) {
	case STMF_CMD_LU_ONLINE:
		if (slu->slu_state == STMF_STATE_ONLINE)
			st.st_completion_status = STMF_ALREADY;
		else if (slu->slu_state != STMF_STATE_OFFLINE)
			st.st_completion_status = STMF_FAILURE;
		if (st.st_completion_status == STMF_SUCCESS) {
			slu->slu_state = STMF_STATE_ONLINE;
			slu->slu_state_not_acked = 1;
		}
		(void) stmf_ctl(STMF_CMD_LU_ONLINE_COMPLETE, lu, &st);
		break;

	case STMF_CMD_LU_OFFLINE:
		if (slu->slu_state == STMF_STATE_OFFLINE)
			st.st_completion_status = STMF_ALREADY;
		else if (slu->slu_state != STMF_STATE_ONLINE)
			st.st_completion_status = STMF_FAILURE;
		if (st.st_completion_status == STMF_SUCCESS) {
			slu->slu_flags &= ~(SLUF_MEDIUM_REMOVAL_PREVENTED |
			    SLUF_LU_HAS_SCSI2_RESERVATION);
			slu->slu_state = STMF_STATE_OFFLINE;
			slu->slu_state_not_acked = 1;
		}
		(void) stmf_ctl(STMF_CMD_LU_OFFLINE_COMPLETE, lu, &st);
		break;

	case STMF_ACK_LU_ONLINE_COMPLETE:
		/* Fallthrough */
	case STMF_ACK_LU_OFFLINE_COMPLETE:
		slu->slu_state_not_acked = 0;
		break;

	}
}

stmf_status_t
stt_task_alloc(struct scsi_task *task)
{
	if ((task->task_lu_private =
	    kmem_alloc(sizeof (stt_cmd_t), KM_NOSLEEP)) != NULL) {
		stt_cmd_t *scmd = (stt_cmd_t *)task->task_lu_private;
		scmd->flags = 0;
		return (STMF_SUCCESS);
	}
	return (STMF_ALLOC_FAILURE);
}

void
stt_remove_it_handle(stt_lu_t *slu, stt_it_data_t *it)
{
	stt_it_data_t **ppit;

	mutex_enter(&slu->slu_lock);
	for (ppit = &slu->slu_it_list; *ppit != NULL;
	    ppit = &((*ppit)->stt_it_next)) {
		if ((*ppit) == it) {
			*ppit = it->stt_it_next;
			break;
		}
	}
	mutex_exit(&slu->slu_lock);

	kmem_free(it, sizeof (*it));
}

void
stt_check_and_clear_scsi2_reservation(stt_lu_t *slu, stt_it_data_t *it)
{
	mutex_enter(&slu->slu_lock);
	if ((slu->slu_flags & SLUF_LU_HAS_SCSI2_RESERVATION) == 0) {
		/* If we dont have any reservations, just get out. */
		mutex_exit(&slu->slu_lock);
		return;
	}

	if (it == NULL) {
		/* Find the I_T nexus which is holding the reservation. */
		for (it = slu->slu_it_list; it != NULL; it = it->stt_it_next) {
			if (it->stt_it_flags & STT_IT_HAS_SCSI2_RESERVATION) {
				ASSERT(it->stt_it_session_id ==
				    slu->slu_rs_owner_session_id);
				break;
			}
		}
		ASSERT(it != NULL);
	} else {
		/*
		 * We were passed an I_T nexus. If this nexus does not hold
		 * the reservation, do nothing. This is why this function is
		 * called "check_and_clear".
		 */
		if ((it->stt_it_flags & STT_IT_HAS_SCSI2_RESERVATION) == 0) {
			mutex_exit(&slu->slu_lock);
			return;
		}
	}
	it->stt_it_flags &= ~STT_IT_HAS_SCSI2_RESERVATION;
	slu->slu_flags &= ~SLUF_LU_HAS_SCSI2_RESERVATION;
	mutex_exit(&slu->slu_lock);
}

void
stt_handle_inquiry(struct scsi_task *task, struct stmf_data_buf *initial_dbuf)
{
	uint8_t *cdbp = (uint8_t *)&task->task_cdb[0];
	uint8_t *p;
	uint8_t byte0;
	uint8_t page_length;
	uint16_t bsize = 512;
	uint16_t cmd_size;
	uint32_t xfer_size = 4;


	byte0 = DTYPE_SEQUENTIAL;

	/*
	 * Basic protocol checks.
	 */
	if ((((cdbp[1] & 1) == 0) && cdbp[2]) || cdbp[5]) {
		stmf_scsilib_send_status(task, STATUS_CHECK,
		    STMF_SAA_INVALID_FIELD_IN_CDB);
		return;
	}

	/*
	 * Zero byte allocation length is not an error.  Just
	 * return success.
	 */

	cmd_size = (((uint16_t)cdbp[3]) << 8) | cdbp[4];

	if (cmd_size == 0) {
		task->task_cmd_xfer_length = 0;
		if (task->task_additional_flags &
		    TASK_AF_NO_EXPECTED_XFER_LENGTH) {
			task->task_expected_xfer_length = 0;
		}
		stmf_scsilib_send_status(task, STATUS_GOOD, 0);
		return;
	}

	/*
	 * Standard inquiry
	 */

	if ((cdbp[1] & 1) == 0) {
		int	i;
		struct scsi_inquiry *inq;

		p = (uint8_t *)kmem_zalloc(bsize, KM_SLEEP);
		inq = (struct scsi_inquiry *)p;

		page_length = 31;
		xfer_size = page_length + 5;

		inq->inq_rmb = 1;
		inq->inq_dtype = DTYPE_SEQUENTIAL;
		inq->inq_ansi = 5;	/* SPC-3 */
		inq->inq_hisup = 1;
		inq->inq_rdf = 2;	/* Response data format for SPC-3 */
		inq->inq_len = page_length;

		inq->inq_tpgs = TPGS_FAILOVER_IMPLICIT;
		inq->inq_cmdque = 1;

		bcopy(stt_vid, inq->inq_vid, 8);
		bcopy("VIRTUAL TAPE    ", inq->inq_pid, 16);
		snprintf(inq->inq_revision, 4, "%d.%d ",
		    STT_VER_MAJOR, STT_VER_MINOR);

		stt_handle_short_read_transfers(task, initial_dbuf, p, cmd_size,
		    min(cmd_size, xfer_size));
		kmem_free(p, bsize);

		return;
	}

	/*
	 * EVPD handling
	 */

	/* Default 512 bytes may not be enough, increase bsize if necessary */
	if (cdbp[2] == 0x83) {
		if (bsize <  cmd_size)
			bsize = cmd_size;
	}
	p = (uint8_t *)kmem_zalloc(bsize, KM_SLEEP);

	switch (cdbp[2]) {
	case 0x00:
		page_length = 4;

		p[0] = byte0;
		p[3] = page_length;
		/* Supported VPD pages in ascending order */
		{
			uint8_t i = 5;

			p[i++] = 0x80;
			p[i++] = 0x83;
			p[i++] = 0x86;
		}
		xfer_size = page_length + 4;
		break;

	case 0x80:
		page_length = 4;
		bcopy("    ", p + 4, 4);
		p[0] = byte0;
		p[1] = 0x80;
		p[3] = page_length;
		xfer_size = page_length + 4;
		break;

	case 0x83:
		xfer_size = stmf_scsilib_prepare_vpd_page83(task, p,
		    bsize, byte0, STMF_VPD_LU_ID|STMF_VPD_TARGET_ID|
		    STMF_VPD_TP_GROUP|STMF_VPD_RELATIVE_TP_ID);
		break;

	case 0x86:
		page_length = 0x3c;

		p[0] = byte0;
		p[1] = 0x86;		/* Page 86 response */
		p[3] = page_length;

		/*
		 * Bits 0, 1, and 2 will need to be updated
		 * to reflect the queue tag handling if/when
		 * that is implemented.  For now, we're going
		 * to claim support only for Simple TA.
		 */
		p[5] = 1;
		xfer_size = page_length + 4;
		break;

	default:
		stmf_scsilib_send_status(task, STATUS_CHECK,
		    STMF_SAA_INVALID_FIELD_IN_CDB);
		kmem_free(p, bsize);
		return;
	}

	stt_handle_short_read_transfers(task, initial_dbuf, p, cmd_size,
	    min(cmd_size, xfer_size));
	kmem_free(p, bsize);
}

int
stt_check_media(stt_lu_t *slu, struct scsi_task *task, int bump_ref, int excl)
{
	/*
	 * Note Excl can only be set if bump ref is set.
	 */
	if (bump_ref) {
		mutex_enter(&slu->slu_lock);
		if (slu->slu_flags & SLUF_ALLOW_MEDIA_ACCESS) {
			if (excl && slu->slu_ntasks_needing_media) {
				mutex_exit(&slu->slu_lock);
				stmf_scsilib_send_status(task, STATUS_BUSY, 0);
				return (1);
			}
			task->task_additional_flags |= TASK_AF_NEED_REF_REMOVAL;
			atomic_add_32(&slu->slu_ntasks_needing_media, 1);
			mutex_exit(&slu->slu_lock);
			return (0);
		} else {
			mutex_exit(&slu->slu_lock);
			stmf_scsilib_send_status(task, STATUS_CHECK,
			    STMF_SAA_MEDIUM_NOT_PRESENT);
			return (1);
		}
	}
	ASSERT(excl == 0);
	if (slu->slu_flags & SLUF_ALLOW_MEDIA_ACCESS)
		return (0);
	stmf_scsilib_send_status(task, STATUS_CHECK,
	    STMF_SAA_MEDIUM_NOT_PRESENT);
	return (1);
}

void
stt_send_status(scsi_task_t *task, uint8_t st, uint8_t sensef,
    uint32_t saa, uint32_t info)
{
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	uint8_t sd[18];

	STT_REMOVE_REF(slu, task);
	task->task_scsi_status = st;
	if (st == STATUS_CHECK) {
		bzero(sd, 18);
		if (sensef & SENSEF_INFO_VALID) {
			sd[0] = 0xF0;
			sd[3] = (info >> 24) & 0xff;
			sd[4] = (info >> 16) & 0xff;
			sd[5] = (info >> 8) & 0xff;
			sd[6] = info & 0xff;
		} else {
			sd[0] = 0x70;
		}
		sd[2] = ((saa >> 16) & 0xf) | (sensef & 0xf0);
		sd[7] = 10;
		sd[12] = (saa >> 8) & 0xff;
		sd[13] = saa & 0xff;
		task->task_sense_data = sd;
		task->task_sense_length = 18;
	} else {
		task->task_sense_data = NULL;
		task->task_sense_length = 0;
	}
	(void) stmf_send_scsi_status(task, STMF_IOF_LU_DONE);
}


void
stt_new_task(struct scsi_task *task, struct stmf_data_buf *initial_dbuf)
{
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	stt_it_data_t *it;
	uint8_t cdb0, cdb1;
	stmf_status_t st_ret;

	if ((it = task->task_lu_itl_handle) == NULL) {
		mutex_enter(&slu->slu_lock);
		for (it = slu->slu_it_list; it != NULL; it = it->stt_it_next) {
			if (it->stt_it_session_id ==
			    task->task_session->ss_session_id) {
				mutex_exit(&slu->slu_lock);
				stmf_scsilib_send_status(task, STATUS_BUSY, 0);
				return;
			}
		}
		it = (stt_it_data_t *)kmem_zalloc(sizeof (*it), KM_NOSLEEP);
		if (it == NULL) {
			mutex_exit(&slu->slu_lock);
			stmf_scsilib_send_status(task, STATUS_BUSY, 0);
			return;
		}
		it->stt_it_session_id = task->task_session->ss_session_id;
		bcopy(task->task_lun_no, it->stt_it_lun, 8);
		it->stt_it_next = slu->slu_it_list;
		slu->slu_it_list = it;
		mutex_exit(&slu->slu_lock);

		if (stmf_register_itl_handle(task->task_lu, task->task_lun_no,
		    task->task_session, it->stt_it_session_id, it)
		    != STMF_SUCCESS) {
			stt_remove_it_handle(slu, it);
			stmf_scsilib_send_status(task, STATUS_BUSY, 0);
			return;
		}
		task->task_lu_itl_handle = it;
		it->stt_it_ua_conditions = STT_UA_POR;
	}

	if (task->task_mgmt_function) {
		stmf_scsilib_handle_task_mgmt(task);
		return;
	}

	/* Checking ua conditions as per SAM3R14 5.3.2 specified order */
	if ((it->stt_it_ua_conditions) && (task->task_cdb[0] != SCMD_INQUIRY)) {
		uint32_t saa = 0;

		mutex_enter(&slu->slu_lock);
		if (it->stt_it_ua_conditions & STT_UA_POR) {
			it->stt_it_ua_conditions &= ~STT_UA_POR;
			saa = STMF_SAA_POR;
		}
		mutex_exit(&slu->slu_lock);
		if (saa) {
			stmf_scsilib_send_status(task, STATUS_CHECK, saa);
			return;
		}
	}

	/* Reservation conflict checks */
	if ((slu->slu_flags & SLUF_LU_HAS_SCSI2_RESERVATION) &&
	    ((it->stt_it_flags & STT_IT_HAS_SCSI2_RESERVATION) == 0)) {
		if (!(SCSI2_CONFLICT_FREE_CMDS(task->task_cdb))) {
			stmf_scsilib_send_status(task,
			    STATUS_RESERVATION_CONFLICT, 0);
			return;
		}
	}

	/* Rest of the ua conndition checks */
	if ((it->stt_it_ua_conditions) && (task->task_cdb[0] != SCMD_INQUIRY)) {
		uint32_t saa = 0;

		mutex_enter(&slu->slu_lock);
		if (it->stt_it_ua_conditions &
		    STT_UA_MODE_PARAMETERS_CHANGED) {
			it->stt_it_ua_conditions &=
			    ~STT_UA_MODE_PARAMETERS_CHANGED;
			saa = STMF_SAA_MODE_PARAMETERS_CHANGED;
		} else if (it->stt_it_ua_conditions & STT_UA_MEDIUM_LOADED) {
			it->stt_it_ua_conditions &= ~STT_UA_MEDIUM_LOADED;
			saa = STMF_SAA_MEDIUM_LOADED;
		} else {
			it->stt_it_ua_conditions = 0;
			saa = 0;
		}
		mutex_exit(&slu->slu_lock);
		if (saa) {
			stmf_scsilib_send_status(task, STATUS_CHECK, saa);
			return;
		}
	}

	cdb0 = task->task_cdb[0];
	cdb1 = task->task_cdb[1];

	if (cdb0 == SCMD_WRITE) {
		if (stt_check_media(slu, task, 1, 1))
			return;
		stt_handle_write(task, initial_dbuf);
		return;
	}

	if (cdb0 == SCMD_READ) {
		if (stt_check_media(slu, task, 1, 1))
			return;
		stt_handle_read(task, initial_dbuf);
		return;
	}

	if (cdb0 == SCMD_INQUIRY) {
		stt_handle_inquiry(task, initial_dbuf);
		return;
	}

	if (cdb0 == SCMD_REQUEST_SENSE) {
		/*
		 * No additional sense data.
		 */

		if ((cdb1 & ~1) || task->task_cdb[2] || task->task_cdb[3] ||
		    task->task_cdb[5]) {
			stmf_scsilib_send_status(task, STATUS_CHECK,
			    STMF_SAA_INVALID_FIELD_IN_CDB);
		} else {
			stmf_scsilib_send_status(task, STATUS_GOOD, 0);
		}

		return;
	}

	if (cdb0 == SCMD_TEST_UNIT_READY) {
		task->task_cmd_xfer_length = 0;
		if (!stt_check_media(slu, task, 0, 0))
			stmf_scsilib_send_status(task, STATUS_GOOD, 0);
		return;
	}

	if (cdb0 == SCMD_REWIND) {
		task->task_cmd_xfer_length = 0;
		if (stt_check_media(slu, task, 1, 1))
			return;

		slu->slu_cur_file = 0;
		slu->slu_cur_off = 0;
		STT_REMOVE_REF(slu, task);
		stmf_scsilib_send_status(task, STATUS_GOOD, 0);
		return;
	}

	if (cdb0 == SCMD_READ_BLKLIM) {
		stt_handle_read_blklim(task, initial_dbuf);
		return;
	}

	if (cdb0 == SCMD_WRITE_FILE_MARK) {
		if (stt_check_media(slu, task, 1, 1))
			return;
		stt_handle_write_filemarks(task);
		return;
	}

	if (cdb0 == SCMD_SPACE) {
		if (stt_check_media(slu, task, 1, 1))
			return;
		stt_handle_space(task);
		return;
	}

	if (cdb0 == SCMD_MODE_SENSE) {
		uint8_t *p;
		if (stt_check_media(slu, task, 0, 0))
			return;
		p = kmem_zalloc(512, KM_SLEEP);
		stt_handle_mode_sense(task, initial_dbuf, p);
		kmem_free(p, 512);
		return;
	}

	if (cdb0 == SCMD_MODE_SELECT) {
		if (stt_check_media(slu, task, 1, 1))
			return;
		stt_handle_mode_select(task, initial_dbuf);
		return;
	}

	if (cdb0 == SCMD_DOORLOCK) {
		if (stt_check_media(slu, task, 1, 0))
			return;
		stt_handle_doorlock(task);
		return;
	}

	stmf_scsilib_send_status(task, STATUS_CHECK, STMF_SAA_INVALID_OPCODE);
}

void
stt_dbuf_xfer_done(struct scsi_task *task, struct stmf_data_buf *dbuf)
{
	stt_cmd_t *scmd = NULL;

	scmd = (stt_cmd_t *)task->task_lu_private;
	if ((scmd == NULL) || ((scmd->flags & STT_SCSI_CMD_ACTIVE) == 0))
		return;

	switch (scmd->cmd_type) {
	case (STT_CMD_SCSI_READ):
		stt_handle_read_xfer_completion(task, scmd, dbuf);
		break;
	case (STT_CMD_SCSI_WRITE):
		stt_handle_write_xfer_completion(task, scmd, dbuf, 1);
		break;
	case (STT_CMD_SMALL_READ):
		stt_handle_short_read_xfer_completion(task, scmd, dbuf);
		break;

	case (STT_CMD_SMALL_WRITE):
		stt_handle_short_write_xfer_completion(task, dbuf);
		break;

	default:
		cmn_err(CE_PANIC, "Unknown cmd type, task = %p", (void *)task);
		break;
	}
}

void
stt_send_status_done(struct scsi_task *task)
{
	cmn_err(CE_PANIC,
	    "stt_send_status_done: this should not have been called");
}

void
stt_task_free(struct scsi_task *task)
{
	if (task->task_lu_private) {
		stt_cmd_t *scmd = (stt_cmd_t *)task->task_lu_private;
		if (scmd->flags & STT_SCSI_CMD_ACTIVE) {
			cmn_err(CE_PANIC, "cmd is active, task = %p",
			    (void *)task);
		}
		kmem_free(scmd, sizeof (stt_cmd_t));
	}
}

/*
 * If this function is called, we are doing nothing with this task
 * inside of stt module.
 */
stmf_status_t
stt_abort(struct stmf_lu *lu, int abort_cmd, void *arg, uint32_t flags)
{
	stt_lu_t *slu = (stt_lu_t *)lu->lu_provider_private;
	scsi_task_t *task;

	if (abort_cmd == STMF_LU_RESET_STATE) {
		return (stt_lu_reset_state(lu));
	}

	if (abort_cmd == STMF_LU_ITL_HANDLE_REMOVED) {
		/*
		 * This should not be done blindly but SPC3 does not
		 * really specify that this needs to be tracked in a per
		 * I_T basis.
		 */
		mutex_enter(&slu->slu_lock);
		slu->slu_flags &= ~SLUF_MEDIUM_REMOVAL_PREVENTED;
		mutex_exit(&slu->slu_lock);

		stt_check_and_clear_scsi2_reservation(slu,
		     (stt_it_data_t *)arg);
		stt_remove_it_handle(slu, (stt_it_data_t *)arg);
		return (STMF_SUCCESS);
	}

	ASSERT(abort_cmd == STMF_LU_ABORT_TASK);
	task = (scsi_task_t *)arg;
	STT_REMOVE_REF(slu, task);
	if (task->task_lu_private) {
		stt_cmd_t *scmd = (stt_cmd_t *)task->task_lu_private;

		if (scmd->flags & STT_SCSI_CMD_ACTIVE) {
			scmd->flags &= ~STT_SCSI_CMD_ACTIVE;
			return (STMF_ABORT_SUCCESS);
		}
	}

	return (STMF_NOT_FOUND);
}

stmf_status_t
stt_info(uint32_t cmd, stmf_lu_t *lu, void *arg, uint8_t *buf,
    uint32_t *bufsizep)
{
	return (STMF_NOT_SUPPORTED);
}

stmf_status_t
stt_lu_reset_state(stmf_lu_t *lu)
{
	stt_lu_t *slu = (stt_lu_t *)lu->lu_provider_private;

	mutex_enter(&slu->slu_lock);
	slu->slu_flags &= ~SLUF_MEDIUM_REMOVAL_PREVENTED;
	mutex_exit(&slu->slu_lock);

	stt_check_and_clear_scsi2_reservation(slu, NULL);
	if (stmf_deregister_all_lu_itl_handles(lu) != STMF_SUCCESS) {
		return (STMF_FAILURE);
	}
	return (STMF_SUCCESS);
}

void
stt_handle_read_blklim(struct scsi_task *task,
    struct stmf_data_buf *initial_dbuf)
{
	uint32_t b;
	uint8_t p[6];

	p[0] = 9;
	b = 8 * 1024 * 1024;
	p[1] = (b >> 16) & 0xff;
	p[2] = (b >> 8) & 0xff;
	p[3] = b & 0xff;
	p[4] = 2;
	p[5] = 0;
	stt_handle_short_read_transfers(task, initial_dbuf, p, 6, 6);
}

void
stt_handle_write_filemarks(struct scsi_task *task)
{
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	stt_partition_info_t *spi = slu->slu_spi;
	stt_lobj_t *slob;
	uint32_t num, sz;
	uint64_t new_start, size_left;
	int i;

	num = task->task_cdb[2];
	num <<= 8;
	num |= task->task_cdb[3];
	num <<= 8;
	num |= task->task_cdb[4];
	if ((task->task_cdb[1] & 2) || (num > 1)) {
		STT_REMOVE_REF(slu, task);
		stmf_scsilib_send_status(task, STATUS_CHECK,
		    STMF_SAA_INVALID_FIELD_IN_CDB);
		return;
	}
	if (num == 0) {
		goto filemark_written;
	}
	slob = &spi->spi_slobs[slu->slu_cur_file];
	if ((spi->spi_num_slobs == spi->spi_max_slobs) ||
	    (slob->slob_max_size == 0)) {
		/* No room for any more filemarks */
		STT_REMOVE_REF(slu, task);
		stmf_scsilib_send_status(task, STATUS_CHECK,
		    STMF_SAA_OVERFLOW_EOP);
		return;
	}
	mutex_enter(&slu->slu_lock);
	/* Are we removing some files */
	if (slu->slu_cur_file < (spi->spi_num_slobs - 1)) {
		slob->slob_max_size = slu->slu_media_file->f_size -
		    slob->slob_start_addr;
		spi->spi_num_slobs = slu->slu_cur_file + 1;
		slu->slu_flags |= SLUF_MEDIA_META_DIRTY;
	}
	/* If current offset is zero, just reuse this file */
	if (slu->slu_cur_off == 0) {
		slob->slob_valid_data_size = 0;
		slu->slu_flags |= SLUF_MEDIA_META_DIRTY;
		mutex_exit(&slu->slu_lock);
		goto filemark_written;
	}
	/* Add a new entry */
	sz = spi->spi_num_slobs + 1;
	sz *= sizeof (stt_lobj_t);
	sz += STT_MEDIA_PAR_INFO_SIZE + 511;
	sz &= ~511;
	if (spi->spi_alloc_size < sz) {
		stt_partition_info_t *old;

		mutex_exit(&slu->slu_lock);
		spi = kmem_alloc(sz, KM_SLEEP);
		mutex_enter(&slu->slu_lock);
		bcopy(slu->slu_spi, spi, slu->slu_spi->spi_alloc_size);
		spi->spi_alloc_size = sz;
		spi->spi_slobs = (stt_lobj_t *)GET_BYTE_OFFSET(spi,
		    STT_MEDIA_PAR_INFO_SIZE);
		old = slu->slu_spi;
		slu->slu_spi = spi;
		kmem_free(old, old->spi_alloc_size);
		slob = &spi->spi_slobs[slu->slu_cur_file];
	}

	slob->slob_valid_data_size = slu->slu_cur_off;
	size_left = slob->slob_max_size - slob->slob_valid_data_size;
	slob->slob_max_size = slob->slob_valid_data_size;
	new_start = slob->slob_start_addr + slob->slob_valid_data_size;
	slu->slu_cur_file++;
	slu->slu_cur_off = 0;
	slob = &spi->spi_slobs[slu->slu_cur_file];
	slob->slob_start_addr = new_start;
	slob->slob_max_size = size_left;
	slob->slob_valid_data_size = 0;
	spi->spi_num_slobs++;
	slu->slu_flags |= SLUF_MEDIA_META_DIRTY;
	mutex_exit(&slu->slu_lock);

filemark_written:;
	if (slu->slu_flags & SLUF_MEDIA_META_DIRTY) {
		int err;
		int ret;

		ret = stt_file_pwrite(slu->slu_media_file,
		    (uint8_t *)slu->slu_spi, 0, slu->slu_spi->spi_alloc_size,
		    &err);
		if (ret) {
			cmn_err(CE_WARN, "meta update failed: err=%d", err);
			STT_REMOVE_REF(slu, task);
			stmf_scsilib_send_status(task, STATUS_CHECK,
			    STMF_SAA_WRITE_ERROR);
			return;
		}
		mutex_enter(&slu->slu_lock);
		slu->slu_flags &= ~SLUF_MEDIA_META_DIRTY;
		mutex_exit(&slu->slu_lock);
	}
	(void)stt_flush_write_cache(slu->slu_media_file, 0);
	STT_REMOVE_REF(slu, task);
	stmf_scsilib_send_status(task, STATUS_GOOD, 0);
}

void
stt_handle_space(struct scsi_task *task)
{
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	stt_lobj_t *slob;
	uint8_t *cdb;
	uint32_t c, n;
	int count;
	uint32_t acount;
	uint64_t nbytes;

	cdb = task->task_cdb;
	c = cdb[2];
	c <<= 8;
	c |= cdb[3];
	c <<= 8;
	c |= cdb[4];

	if (c & 0x800000) {
		c |= 0xFF000000;
	}
	count = (int)c;
	if (count < 0)
		acount = (uint32_t)(0 - count);
	else
		acount = (uint32_t)count;

	if (((cdb[1] & 0xf) != 0) && ((cdb[1] & 0xf) != 1) &&
	    ((cdb[1] & 0xf) != 3)) {
		stt_send_status(task, STATUS_CHECK, SENSEF_INFO_VALID,
		    STMF_SAA_INVALID_FIELD_IN_CDB, acount);
		return;
	}

	(void)stt_flush_write_cache(slu->slu_media_file, 0);
	if ((cdb[1] & 0xf) == 3) {
		mutex_enter(&slu->slu_lock);
		slu->slu_cur_file = slu->slu_spi->spi_num_slobs - 1;
		slob = &slu->slu_spi->spi_slobs[slu->slu_cur_file];
		slu->slu_cur_off = slob->slob_valid_data_size;
		mutex_exit(&slu->slu_lock);
		stt_send_status(task, STATUS_GOOD, 0, 0, 0);
		return;
	}
	if (acount == 0) {
		goto space_done;
	}
	if ((cdb[1] & 0xf) == 1) {
		/* We are skipping over filemarks */
		if (count < 0) { /* Reverse */
			mutex_enter(&slu->slu_lock);
			if (acount > slu->slu_cur_file) {
				acount -= slu->slu_cur_file;
				slu->slu_cur_file = 0;
				slu->slu_cur_off = 0;
				mutex_exit(&slu->slu_lock);
				stt_send_status(task, STATUS_CHECK,
				    SENSEF_INFO_VALID | SENSEF_EOM,
				    STMF_SAA_BOP_DETECTED, acount);
				return;
			}
			slu->slu_cur_file -= acount;
			slu->slu_cur_off = 0;
			mutex_exit(&slu->slu_lock);
			stt_send_status(task, STATUS_GOOD, 0, 0, 0);
			return;
		}
		/* Forward skipping */
		mutex_enter(&slu->slu_lock);
		if (acount > (slu->slu_spi->spi_num_slobs -
		    slu->slu_cur_file - 1)) {
			acount -= (slu->slu_spi->spi_num_slobs -
			    slu->slu_cur_file - 1);
			slu->slu_cur_file = slu->slu_spi->spi_num_slobs - 1;
			slob = &slu->slu_spi->spi_slobs[slu->slu_cur_file];
			slu->slu_cur_off = slob->slob_valid_data_size;
			mutex_exit(&slu->slu_lock);
			if (slu->slu_cur_off == slob->slob_max_size) {
				stt_send_status(task, STATUS_CHECK,
				    SENSEF_INFO_VALID | SENSEF_EOM,
				    STMF_SAA_SENSE_EOP_DETECTED, acount);
				return;
			}
			stt_send_status(task, STATUS_CHECK,
			    SENSEF_INFO_VALID, STMF_SAA_EOD_DETECTED, acount);
			return;
		}
		slu->slu_cur_file += acount;
		slu->slu_cur_off = 0;
		mutex_exit(&slu->slu_lock);
		stt_send_status(task, STATUS_GOOD, 0, 0, 0);
		return;
	}
				
	slob = &slu->slu_spi->spi_slobs[slu->slu_cur_file];
	nbytes = (uint64_t)((uint64_t)acount * (uint64_t)slu->slu_cur_blksize);
	mutex_enter(&slu->slu_lock);
	if (count < 0) {
		if (nbytes > slu->slu_cur_off) {
			nbytes -= slu->slu_cur_off;
			if (slu->slu_cur_file) {
				slu->slu_cur_file--;
				slob = &slu->slu_spi->spi_slobs[
				    slu->slu_cur_file];
				slu->slu_cur_off = slob->slob_valid_data_size;
				mutex_exit(&slu->slu_lock);
				stt_send_status(task, STATUS_CHECK,
				    SENSEF_INFO_VALID | SENSEF_FILEMARK,
				    STMF_SAA_FILEMARK_DETECTED,
				    (uint32_t)(nbytes / slu->slu_cur_blksize));
				return;
			}
			slu->slu_cur_off = 0;
			mutex_exit(&slu->slu_lock);
			stt_send_status(task, STATUS_CHECK,
			    SENSEF_EOM | SENSEF_INFO_VALID,
			    STMF_SAA_BOP_DETECTED,
			    (uint32_t)(nbytes / slu->slu_cur_blksize));
			return;
		}
		slu->slu_cur_off -= nbytes;
		mutex_exit(&slu->slu_lock);
		stt_send_status(task, STATUS_GOOD, 0, 0, 0);
		return;
	}
	if (nbytes > (slob->slob_valid_data_size - slu->slu_cur_off)) {
		nbytes -= slob->slob_valid_data_size - slu->slu_cur_off;
		if (slob->slob_valid_data_size < slob->slob_max_size) {
			slu->slu_cur_off = slob->slob_valid_data_size;
			mutex_exit(&slu->slu_lock);
			stt_send_status(task, STATUS_CHECK,
			    SENSEF_INFO_VALID, STMF_SAA_EOD_DETECTED,
			    (uint32_t)(nbytes / slu->slu_cur_blksize));
			return;
		}
		if (slu->slu_cur_file < (slu->slu_spi->spi_num_slobs - 1)) {
			slu->slu_cur_file++;
			slu->slu_cur_off = 0;
			slob = &slu->slu_spi->spi_slobs[slu->slu_cur_file];
			mutex_exit(&slu->slu_lock);
			if (slob->slob_max_size == 0) {
				stt_send_status(task, STATUS_CHECK,
				    SENSEF_EOM | SENSEF_INFO_VALID,
				    STMF_SAA_SENSE_EOP_DETECTED,
				    (uint32_t)(nbytes / slu->slu_cur_blksize));
			} else {
				stt_send_status(task, STATUS_CHECK,
				    SENSEF_INFO_VALID | SENSEF_FILEMARK,
				    STMF_SAA_FILEMARK_DETECTED,
				    (uint32_t)(nbytes / slu->slu_cur_blksize));
			}
			return;
		}
		slu->slu_cur_off = slob->slob_valid_data_size;
		mutex_exit(&slu->slu_lock);
		stt_send_status(task, STATUS_CHECK,
		    SENSEF_INFO_VALID | SENSEF_FILEMARK,
		    STMF_SAA_FILEMARK_DETECTED,
		    (uint32_t)(nbytes / slu->slu_cur_blksize));
		return;
	}
	slu->slu_cur_off += nbytes;
	mutex_exit(&slu->slu_lock);
space_done:
	stt_send_status(task, STATUS_GOOD, 0, 0, 0);
}

void
stt_handle_mode_sense(scsi_task_t *task, stmf_data_buf_t *initial_dbuf,
    uint8_t *buf)
{
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	uint8_t *p, *cdb;
	uint8_t page, ctrl, pc_valid, u;
	uint32_t cmd_size;
	uint64_t s;

	p = buf;
	cdb = &task->task_cdb[0];
	page = cdb[2] & 0x3F;
	ctrl = (cdb[2] >> 6) & 3;
	cmd_size = cdb[4];

	if ((cdb[2] == 0) || (page == MODEPAGE_ALLPAGES) || (page == 0x10) ||
	    (page == 0x11)) {
		pc_valid = 1;
	} else {
		pc_valid = 0;
	}

	if (pc_valid == 0) {
		stmf_scsilib_send_status(task, STATUS_CHECK,
		    STMF_SAA_INVALID_FIELD_IN_CDB);
		return;
	}

	/* Fill in the header */
	p[1] = 0;
	p[2] = slu->slu_flags & SLUF_WRITE_PROTECTED ? 0x80 : 0;
	p[3] = 0;
	p += 4;

	/* Fill in block descriptor */
	if (cdb[1] & 8)
		goto over_bd;
	p[-1] = 8;
	*((uint64_t *)p) = 0;
	if (slu->slu_cur_blksize == 0)
		slu->slu_cur_blksize = 512;
	p[7] = slu->slu_cur_blksize & 0xff;
	p[6] = (slu->slu_cur_blksize >> 8) & 0xff;
	p[5] = (slu->slu_cur_blksize >> 16) & 0xff;
	p += 8;
over_bd:

	if ((page == MODEPAGE_ALLPAGES) || (page == 0x10)) {
		bzero(p, 16);
		p[0] = 0x10;
		p[1] = 0xe;
		if (ctrl != 1) {
			p[8] = 0x10;
			p[10] = 2;
		}
		p += 16;
	}

	if ((page == MODEPAGE_ALLPAGES) || (page == 0x11)) {
		bzero(p, 10);
		p[0] = 0x11;
		p[1] = 0x8;
		if (ctrl != 1) {
			p[4] = 0x11;
			s = slu->slu_media_file->f_size;
			u = 0;
			while (s > 65535) {
				s /= 1000;
				u += 3;
			}
			p[6] = u & 0xf;
			p[9] = s & 0xff;
			p[8] = (s >> 8) & 0xff;
		}
		p += 10;
	}
	buf[0] = ((uint8_t)(p - buf)) - 1;
	stt_handle_short_read_transfers(task, initial_dbuf, buf, cmd_size,
	    p - buf);
}

void
stt_handle_mode_select(scsi_task_t *task, stmf_data_buf_t *dbuf)
{
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	uint32_t cmd_xfer_len;

	cmd_xfer_len = (uint32_t)task->task_cdb[4];

	if ((task->task_cdb[1] & 0xFE) != 0x10) {
		STT_REMOVE_REF(slu, task);
		stmf_scsilib_send_status(task, STATUS_CHECK,
		    STMF_SAA_INVALID_FIELD_IN_CDB);
		return;
	}

	if (cmd_xfer_len == 0) {
		/* zero byte mode selects are allowed */
		STT_REMOVE_REF(slu, task);
		stmf_scsilib_send_status(task, STATUS_GOOD, 0);
		return;
	}

	stt_handle_short_write_transfers(task, dbuf, cmd_xfer_len);
}

void
stt_handle_mode_select_xfer(scsi_task_t *task, uint8_t *buf, uint32_t buflen)
{
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	uint32_t b;

	if (buflen != 12) {
		goto mode_sel_param_len_err;
	}
	if (buf[3] == 0) {
		/* Mode select is only for changing blksize */
		goto mode_sel_param_field_err;
	}

	b = buf[9];
	b <<= 8;
	b |= buf[10];
	b <<= 8;
	b |= buf[11];

	if ((b == 0) || (b & 511)) {
		goto mode_sel_param_field_err;
	}
	slu->slu_cur_blksize = b;
	STT_REMOVE_REF(slu, task);
	stmf_scsilib_send_status(task, STATUS_GOOD, 0);
	return;

mode_sel_param_len_err:
	STT_REMOVE_REF(slu, task);
	stmf_scsilib_send_status(task, STATUS_CHECK,
	    STMF_SAA_PARAM_LIST_LENGTH_ERROR);
	return;
mode_sel_param_field_err:
	STT_REMOVE_REF(slu, task);
	stmf_scsilib_send_status(task, STATUS_CHECK,
	    STMF_SAA_INVALID_FIELD_IN_PARAM_LIST);
}

void
stt_handle_doorlock(scsi_task_t *task)
{
	stt_lu_t *slu = (stt_lu_t *)task->task_lu->lu_provider_private;
	uint8_t b;

	b = task->task_cdb[4];

	if (b & 0xFE) {
		stt_send_status(task, STATUS_CHECK, 0,
		    STMF_SAA_INVALID_FIELD_IN_CDB, 0);
		return;
	}
	mutex_enter(&slu->slu_lock);
	/*
	 * The action below should consider which I_T is asking for
	 * what but the spec (SPC3) does not mention it.
	 */
	if (b & 1) {
		slu->slu_flags |= SLUF_MEDIUM_REMOVAL_PREVENTED;
	} else {
		slu->slu_flags &= ~SLUF_MEDIUM_REMOVAL_PREVENTED;
	}
	mutex_exit(&slu->slu_lock);
	stt_send_status(task, STATUS_GOOD, 0, 0, 0);
}
