#!/bin/perl
use strict;

# A message about running tests and expectation.
our $helpmsg = <<TESTHELP;

NAME
    stt_test - Automated tests for the COMSTAR Tape Emulation LU provider.

SYNOPSIS
    stt_test.pl [ Log File ]

DESCRIPTION
    The stt_test.pl is a perl script which does automated testing of the
    stt LU provider. The test script is fairly automated and expects only
    the following from the user:
	- A host running an OpenSolaris based distribution (b124 or above).
	- Solaris iSCSI initiator service installed and enabled.
	- Solaris COMSTAR (SUNWstmf) and COMSTAR iSCSI target installed and
	  enabled.
	- Exactly one iSCSI target created (itadm create-target).
	- stt LU provider installed and sttadm tool is in the PATH.
	- No tape drive attached to the system (physical or virtual).

    Overall this script does the following:
	- Tests the stt LU provider's management interface and
	  management functionality using sttadm.
	- Exposes a tape drive using iSCSI and then accesses that tape
	  drive on the same system using the iscsi initiator over the
	  TCP/IP loopback interface (127.0.0.1). Run various I/O related
	  tests from the initiator side and verify the corrsponding
	  behavior from the tape emulation side.

EXAMPLE
    stt_test.pl /var/tmp/testlog.txt

TESTHELP

sub usage {
	print $helpmsg;
	exit 1;
}

our $LOGFILE="/dev/null";
our $log_en = 1;

if (scalar @ARGV > 0) {
	if (($ARGV[0] eq "-?") || ($ARGV[0] =~ m/help/i)) {
		&usage();
	}
	$LOGFILE = $ARGV[0];
}

open LOGHANDLE, ">", $LOGFILE or die "unable to open $LOGFILE";

sub myprint {
	my ( $msg ) = @_;

	print $msg;
	print LOGHANDLE $msg;
}

sub myprint2 {
	my ( $msg ) = @_;

	print $msg;
	print LOGHANDLE "$msg\n";
}

sub logging_off {
	print LOGHANDLE "-->Turning off the logging<--\n";
	$log_en = 0;
}

sub logging_on {
	print LOGHANDLE "-->Turning on the logging<--\n";
	$log_en = 1;
}

#
# Check for service status
#
my @svcs = ();
sub check_svc {
	my ( $svc_name ) = @_;
	my ( $line, $found );

	if (scalar @svcs == 0) {
		@svcs = `svcs -a`;
	}
	$found = 0;
	for my $line (@svcs) {
		next if ($line !~ m/$svc_name/);
		$found = 1;
		if ($line !~ m/online/) {
			&myprint("Service $svc_name is not online\n");
			exit 1;
		}
		last;
	}
	if (!$found) {
		&myprint("Unable to find service $svc_name \n");
		exit 1;
	}
}

#
# Basic checks
#
my $r;
my $i;
if ($> != 0) {
	&myprint("You must be root to run this program\n");
	exit 1;
}
&check_svc("system/stmf");
&check_svc("iscsi/target");
&check_svc("iscsi/initiator");
$r = system('sttadm list-drives >/dev/null 2>&1');
if ($r) {
	&myprint("sttadm not found or stt driver is not attached.\n\n");
	&usage();
}
$r = system('stmfadm list-lu >/dev/null 2>&1');
if ($r) {
	&myprint("stmfadm not found\n\n");
	&usage();
}
$r = system('iscsiadm list discovery-address >/dev/null 2>&1');
if ($r) {
	&myprint("iscsiadm not found\n\n");
	&usage();
}

# ====== End of Basic checks ======

sub runcmd {
	my ( $cmd, $output ) = @_;
	my ( $ret, @discard );
	if (!defined $output) {
		$output = \@discard;
	}
	if ($log_en) {
		print LOGHANDLE "-> $cmd \n";
	}
	@$output = `$cmd 2>/dev/fd/1`;
	$ret=$?;
	if (defined $output) {
		if ($log_en) {
			print LOGHANDLE @$output;
		}
	} else {
		@$output = ( "" );
	}
	return $ret;
}

sub has_media {
	my ($drive) = @_;
	my ($ret, @o, $line);

	$ret = &runcmd("sttadm drive-info $drive", \@o);
	if ($ret) {
		return 0;
	}

	for $line (@o) {
		next if ($line !~ /Media/);
		if ($line =~ /not present/) {
			return 0;
		}
		return 1;
	}
	return 0;
}

sub setup_tests {
	my ($ret, @o, $guid);

	$ret = &runcmd("sttadm list-drives", \@o);
	if ($ret) {
		&myprint("sttadm failed.\n");
		exit $ret;
	}
	for $guid (@o) {
		$ret = &runcmd("sttadm delete-drive $guid", undef);
		if ($ret) {
			&myprint("Unable to delete drive $guid\n");
			exit 1;
		}
	}
	$ret = &runcmd("sttadm import-drive /var/tmp/drive", \@o);
	if ($ret) {
		$ret = &runcmd("sttadm create-drive /var/tmp/drive",
		    \@o);
		if ($ret) {
			&myprint("Unable to get a drive\n");
			exit $ret;
		}
	}
	$ret = &runcmd("sttadm list-drives", \@o);
	if ($ret) {
		&myprint("sttadm failed.\n");
		exit $ret;
	}
	if (scalar @o != 1) {
		&myprint("Unable to get a drive\n");
		exit 1;
	}
	$guid = @o[0];
	if (&has_media($guid)) {
		&runcmd("sttadm unload-media $guid", undef);
		if (&has_media($guid)) {
			&myprint("Unable to unload media from drive\n");
			exit 1;
		}
	}
	&runcmd("stmfadm add-view $guid", \@o);
	&runcmd("iscsiadm add discovery-address 127.0.0.1", undef);
	&runcmd("iscsiadm modify discovery -t enable", undef);
	&runcmd(undef, undef, undef, 1);
	&runcmd('/bin/rm -rf /dev/rmt/*', undef);
	&runcmd("devfsadm -C", undef);
	$ret = &runcmd("drvconfig -i st", undef);
	if ($ret) {
		&myprint("st driver is failing to attach\n");
		exit 1;
	}
	if (! -e "/dev/rmt/0n") {
		&myprint("/dev/rmt/0 does not exist\n");
		exit 1;
	}
	if (-e "/dev/rmt/1n") {
		&myprint("There is a /dev/rmt/1. Not expected. Please ");
		&myprint("cleanup and retry\n");
		exit 1;
	}
	if (! -e "/dev/rramdisk/media") {
		&runcmd('ramdiskadm -a media 16m', undef);
	}
	if (! -e "/var/tmp/media") {
		&runcmd('mkfile -n 16m /var/tmp/media', undef);
	}
}

sub drive_info {
	my ( $drive, $di ) = @_;
	my ( @o, @files, $ret );

	%{$di} = ();
	$ret = &runcmd("sttadm drive-info -v $drive", \@o);
	if ($ret) {
		print "drive_info: drive-info failed. Exiting...\n";
		exit(1);
	}
	@files = ();
	for my $line (@o) {
		if ($line =~ /^Drive : (\S+)/) {
			$di->{'drive'} = $1;
			next;
		}
		if ($line =~ /\s+GUID : (\S+)/) {
			$di->{'guid'} = $1;
			next;
		}
		if ($line =~ /\s+BlkSize : (\S+)/) {
			$di->{'blksize'} = $1;
			next;
		}
		if ($line =~ /\s+Driver Flags : (\S+)/) {
			$di->{'driver_flags'} = $1;
			next;
		}
		if ($line =~ /\s+Media : (\S+)/) {
			my $md = $1;
			if ($line =~ /not present/) {
				last;
			}
			$di->{'media'} = $md;
			$di->{'files'} = \@files;
			next;
		}
		if ($line =~ /\s+Current Filemark # : (\S+)/) {
			$di->{'current_filemark'} = $1;
			next;
		}
		if ($line =~ /\s+Current Offset : (\S+)/) {
			$di->{'current_offset'} = $1;
			next;
		}
		next if ($line =~ /Partition Info:/);
		next if ($line =~ /File #/);
		next if ($line =~ /------/);
		if ($line =~ /^\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)/) {
			my %h = ();
			$h{'fileno'} = $1;
			$h{'start'} = $2;
			$h{'valid'} = $3;
			$h{'size'} = $4;
			push(@files, \%h);
			next;
		}
		print "drive_info: I should not be here. What did I miss ?\n";
	}
}

sub get_stt_modid {
	my ( @o );

	&runcmd("modinfo", \@o);
	for my $line ( @o ) {
		next if ($line !~ /^\s*(\S+)\s+\S+\s+\S+\s+\S+\s+\S+\s+(\S+)/);
		next if ($2 ne 'stt');
		return ($1);
	}
	return (0);
}

sub unload_stt {
	my ( @o );
	my $id = 0;

	$id = &get_stt_modid();
	if ($id == 0) {
		return;
	}
	&runcmd("echo stt_allow_modunload/W 1 | mdb -kw", undef);
	&runcmd("modunload -i $id", undef);
}

&myprint2("Setting up the test env (Ignore any view-entry msg)...");
&setup_tests();
&myprint("Done\n");

my @o;
my $passed = 0;

&myprint("\nStarting Tests...\n");

# create-drive
&myprint2("Testing create-drive...");
$r = &runcmd("sttadm create-drive /var/tmp/drive2", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# delete-drive
&myprint2("Testing delete-drive...");
$r = &runcmd("sttadm delete-drive /var/tmp/drive2", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# import-drive
&myprint2("Testing import-drive...");
$r = &runcmd("sttadm import-drive /var/tmp/drive2", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# Drive info without media
&myprint2("Testing drive-info without media...");
$r = &runcmd("sttadm drive-info /var/tmp/drive2", \@o);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
if (&has_media("/var/tmp/drive2")) {
	&myprint("FAILED (says has media)\n");
	exit(1);
}
&myprint("passed\n");
$passed++;
&runcmd("sttadm delete-drive /var/tmp/drive2", undef);

# init-media
&myprint2("Testing init-media...");
$r = &runcmd("sttadm init-media /var/tmp/media", \@o);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# init-media -s
&myprint2("Testing init-media -s...");
$r = &runcmd("sttadm init-media -s 128 /dev/rramdisk/media", \@o);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# load-media
&myprint2("Testing load-media...");
$r = &runcmd("sttadm load-media /var/tmp/media /var/tmp/drive", \@o);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

my %di = ();
my @files = ();
my $file_ref;
# drive-info -v
&myprint2("Testing drive-info with media...");
&drive_info("/var/tmp/drive", \%di);
if ((!exists $di{'media'}) || ($di{'media'} != "/var/tmp/media")) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# driver unload
&myprint2("Testing driver unload...");
&unload_stt();
my $id = &get_stt_modid();
if ($id) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# drive and media persistance
&myprint2("Testing drive and media persistance...");
&drive_info("/var/tmp/drive", \%di);
if ((!exists $di{'media'}) || ($di{'media'} != "/var/tmp/media")) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# unload-media
&myprint2("Testing unload-media...");
$r = &runcmd("sttadm unload-media /var/tmp/drive", \@o);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
$r = &runcmd("sttadm load-media /var/tmp/media /var/tmp/drive", \@o);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# access from initiator side
&myprint2("Testing access from initiator side...");
$r = &runcmd("mt -f /dev/rmt/0n status", \@o);
if ($r) {
	$r = &runcmd("mt -f /dev/rmt/0n status", \@o);
}
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
if ($o[0] !~ "VIRTUAL TAPE") {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# IO (WRITE)
&myprint2("Testing I/O (WRITE)...");
&runcmd("dd if=/dev/random of=/tmp/pat1 count=32", undef);
$r = &runcmd("dd if=/tmp/pat1 of=/dev/rmt/0n bs=8k", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&drive_info("/var/tmp/drive", \%di);
if (exists $di{'media'}) {
	$file_ref = $di{'files'};
	@files = @$file_ref;
}
if ((!exists $di{'media'}) || ($di{'media'} != "/var/tmp/media") ||
    ($di{'current_filemark'} != 1) || ($di{'current_offset'} != 0) ||
    (scalar (@files) != 2) || ($files[0]->{'valid'} != 16384)) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# IO (WRITE, APPEND)
&myprint2("Testing I/O (WRITE, APPEND)...");
&runcmd("dd if=/dev/random of=/tmp/pat2 count=32", undef);
$r = &runcmd("dd if=/tmp/pat2 of=/dev/rmt/0n bs=8k", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&drive_info("/var/tmp/drive", \%di);
if (exists $di{'media'}) {
	$file_ref = $di{'files'};
	@files = @$file_ref;
}
if ((!exists $di{'media'}) || ($di{'media'} != "/var/tmp/media") ||
    ($di{'current_filemark'} != 2) || ($di{'current_offset'} != 0) ||
    (scalar (@files) != 3) || ($files[1]->{'valid'} != 16384)) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# mt rewind
&myprint2("Testing 'mt rewind'...");
$r = &runcmd("mt -f /dev/rmt/0n rewind", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&drive_info("/var/tmp/drive", \%di);
if (exists $di{'media'}) {
	$file_ref = $di{'files'};
	@files = @$file_ref;
}
if ((!exists $di{'media'}) || ($di{'media'} != "/var/tmp/media") ||
    ($di{'current_filemark'} != 0) || ($di{'current_offset'} != 0)) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# mt fsf
&myprint2("Testing 'mt fsf'...");
$r = &runcmd("mt -f /dev/rmt/0n fsf", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&drive_info("/var/tmp/drive", \%di);
if (exists $di{'media'}) {
	$file_ref = $di{'files'};
	@files = @$file_ref;
}
if ((!exists $di{'media'}) || ($di{'media'} != "/var/tmp/media") ||
    ($di{'current_filemark'} != 1) || ($di{'current_offset'} != 0)) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# mt asf
&myprint2("Testing 'mt asf'...");
$r = &runcmd("mt -f /dev/rmt/0n asf 0", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&drive_info("/var/tmp/drive", \%di);
if (exists $di{'media'}) {
	$file_ref = $di{'files'};
	@files = @$file_ref;
}
if ((!exists $di{'media'}) || ($di{'media'} != "/var/tmp/media") ||
    ($di{'current_filemark'} != 0) || ($di{'current_offset'} != 0)) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# mt eom
&myprint2("Testing 'mt eom'...");
$r = &runcmd("mt -f /dev/rmt/0n eom", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&drive_info("/var/tmp/drive", \%di);
if (exists $di{'media'}) {
	$file_ref = $di{'files'};
	@files = @$file_ref;
}
if ((!exists $di{'media'}) || ($di{'media'} != "/var/tmp/media") ||
    ($di{'current_filemark'} != 2) || ($di{'current_offset'} != 0) ||
    (scalar (@files) != 3) || ($files[1]->{'valid'} != 16384)) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# IO (READ)
&myprint2("Testing I/O (READ)...");
&runcmd("mt -f /dev/rmt/0n rewind", undef);
$r = &runcmd("dd if=/dev/rmt/0n of=/tmp/g_pat1 bs=8k", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
$r = &runcmd("diff /tmp/pat1 /tmp/g_pat1", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# IO (READ, next filemark)
&myprint2("Testing I/O (READ, next filemark)...");
$r = &runcmd("dd if=/dev/rmt/0n of=/tmp/g_pat2 bs=8k", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
$r = &runcmd("diff /tmp/pat2 /tmp/g_pat2", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# media change
&myprint2("Testing media change...");
$r = &runcmd("sttadm unload-media /var/tmp/drive", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
$r = &runcmd("sttadm load-media /dev/rramdisk/media /var/tmp/drive", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# Write till eom
&myprint2("Testing WRITE till end of partition...");
$r = &runcmd("dd if=/dev/zero of=/dev/rmt/0n bs=8k count=2032", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# Write failure beyond eom
&myprint2("Testing WRITE failure beyond end of partition...");
$r = &runcmd("dd if=/dev/zero of=/dev/rmt/0n bs=8k count=1", undef);
if (!$r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# Read till eom
&myprint2("Testing READ till end of partition...");
&runcmd("mt -f /dev/rmt/0n rewind", undef);
$r = &runcmd("dd if=/dev/rmt/0n of=/dev/null bs=8k count=2032", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# IO (large blksize WRITE)
&myprint2("Testing Large Blocksize WRITE (2M)...");
&runcmd("mt -f /dev/rmt/0n rewind", undef);
&runcmd("dd if=/kernel/drv/amd64/ip of=/tmp/pat1 bs=2048k count=1", undef);
$r = &runcmd("dd if=/tmp/pat1 of=/dev/rmt/0n bs=2048k", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# IO (large blksize READ)
&myprint2("Testing Large Blocksize READ (2M)...");
&runcmd("mt -f /dev/rmt/0n rewind", undef);
$r = &runcmd("dd if=/dev/rmt/0n of=/tmp/g_pat1 bs=2048k", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
$r = &runcmd("diff /tmp/pat1 /tmp/g_pat1", undef);
if ($r) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

# Writing max filemarks
&myprint2("Testing creating max filemarks (may take a while)...");
&runcmd("mt -f /dev/rmt/0n rewind", undef);
&logging_off();
for ($i = 0; $i < 4065; $i++) {
	$r = &runcmd("dd if=/dev/zero of=/dev/rmt/0n count=1", undef);
	if ($r) {
		last;
	}
}
&logging_on();
if ($i != 4063) {
	&myprint("FAILED\n");
	exit(1);
}
&myprint("passed\n");
$passed++;

&myprint("\n$passed Tests Done.\n\n");
exit (0);
